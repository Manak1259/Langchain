#!/bin/bash

# Copyright (c) 2024 Infoblox Inc. All Rights Reserved.
######################################################################################
# Hotfix script in which modification/addition/deletion of files are maintained
# Mandatory fields need to be updated
# 1: File details of modification,  addition or deletion in the below-mentioned format
# 2: JBugID = JIRA bugid of hotfix task
# 3: HfTag = Hotfix tag
#       - Consolidated hotfix -eg: CHF-9.0.1.1
#       - DIAG hotfix         -eg: Hotfix-9.0.1
#       - Custom hotfix       -eg: Hotfix-9.0.1
# 4: IsCHF = Set the backup file tag based on the CHF or custom hotfix
# 5: Version = NIOS version
#
# Note: By default with new hotfix framework supports applying hotfix in
#       distribution complete stage, need to maintain NIOS version as empty 
#       main.sh
#####################################################################################

ONE_BIN_DIR=/infoblox/one/bin
#Infoblox log macros
IB_LOG="${ONE_BIN_DIR}/ib_log -n $0 -f"

if [[ $HFSOURCE -ne 1 ]]; then
  HFSOURCE=1
  source ./hotfix_util.sh
fi

# Files details to modify during hotfix apply
# Format details: 'File name','Directory','Permissions','Weight','Action to perform','MD5SUM_REF','Sub Bug ID','Hardware Type'
# eg: 'modfile1.py','/infoblox/dns/lib/python/infoblox/dns/',"$Perms_RW",10,'Node Restart','831ab6759518748c6de1b38d64537f2d','NIOS-J78059','ALL'
#     'named','/usr/sbin/',"$Perms_EX",5,'DNS Service restart','bb29143e8e8e11413722a9001f4f2ed8','NIOS-J86311','ALL'
ModifyFiles=(
  'clusterd','/infoblox/one/bin/',"$Perms_EX",10,'Node restart','5545da1667ce7e1ef662e46881497f66','NIOS-J98795','ALL'
  'make_sshd_conf','/infoblox/one/bin/',"$Perms_EX",10,'Node restart','3045acc28e84398f4615d92c94db2032','NIOS-J98896','ALL'
  'smart_folder_dbtype.pys','/infoblox/one/lib/python/infoblox/one/',"$Perms_RW",10,'Node restart','e64b8d57fc88b7f701ff77f640934e94','NIOS-J98913-98918','ALL'
  'dhcp_mac_filter.pys','/infoblox/dns/lib/python/infoblox/dns/',"$Perms_RW",10,'Node restart','5bd5ca81ab8f8694a440334930850487','NIOS-J98919','ALL'
  'com.infoblox.module.dashboard_1.0.0.jar','/infoblox/one/webgui/deploy/',"$Perms_RW",5,'GUI restart','4f916a291b03fb0b47421a5982cb3b45','NIOS-J98921','ALL'
  'hsm_iptables_conf','/infoblox/one/bin/',"$Perms_EX",10,'Node restart','20102aa3a3b520d97e324d3592e81e2a','NIOS-J98946','ALL'
  'reporting_control','/infoblox/reporting/bin/',"$Perms_EX",10,'Node restart','19ea34813d5a4bf08c30bb12f72a138e','NIOS-J99000-99001','ALL'
  'defaults.properties','/infoblox/one/webgui/default_configuration/',"$Perms_RW",5,'GUI restart','15654f59659cb7863b98e55cd74d0bac','NIOS-J99082','ALL'
  'com.infoblox.app_1.0.0.jar','/infoblox/one/webgui/deploy/',"$Perms_RW",5,'GUI restart','1b1c75ddbb241c910d5739b2dbed1f5f','NIOS-J99082','ALL'
  'com.infoblox.widget_1.0.0.jar','/infoblox/one/webgui/deploy/',"$Perms_RW",5,'GUI restart','4c7420a718edd5ddd0d2aa61d0bf6ac5','NIOS-J99082','ALL'
  'com.infoblox.module_1.0.0.jar','/infoblox/one/webgui/deploy/',"$Perms_RW",5,'GUI restart','d3e5ff55e2453bead34c468be1169348','NIOS-J99082','ALL'
  'com.infoblox.module.loadbalancer_1.0.0.jar','/infoblox/one/webgui/deploy/',"$Perms_RW",5,'GUI restart','bf450caed235d463fa7d4d6f0ffdf574','NIOS-J99082','ALL'
  'com.infoblox.service_1.0.0.jar','/infoblox/one/webgui/deploy/',"$Perms_RW",5,'GUI restart','2b496906ddb025f1912deeb2d1dc0b74','NIOS-J99082','ALL'
  'dns_common.pys','/infoblox/dns/lib/python/infoblox/dns/',"$Perms_RW",10,'Node restart','c93114e4ea4d886628e5460157182adc','NIOS-J99004','ALL'
  'update_auto_synced_mf','/infoblox/one/bin/',"$Perms_EX",0,'No Action','257e3db5ed5963dbab4887994ab4b1cf','NIOS-J99950','ALL'
)

# Files details to add during hotfix apply
# Format details: 'File name','Directory','Permissions','Weight','Action to perform','MD5SUM_REF','Sub Bug ID','Hardware Type'
# eg: 'addfile1.py','/infoblox/reporting/',"$Perms_EX",5,'Reporting service restart','ce6af5a1fbf6d1633d1cd0c40dba8aea','NIOS-J78059','ALL'
#  'get_splunk_users','/infoblox/one/bin/',"$Perms_EX",5,'Reporting service restart','967b1328b031b28908a9176b6429a5e4','NIOS-J86313','ALL'
AddedFiles=(
)

# Files details to delete during hotfix apply
# Format details: 'File name','Directory','Weight','Action to perform','Sub Bug ID','Hardware Type'
DeletedFiles=(
)

# Files details to modify during hotfix apply in runonce
# Format details: 'File name','Directory','Permissions','MD5SUM_REF','Sub Bug ID','Hardware Type'
# eg: 'rebootmodify1.py','/infoblox/dns/lib64',"$Perms_EX",'63af12d12a941a78bcdbfa483d9bd571','NIOS-J78065','ALL'
#  'libibmmdb.so','/infoblox/dns/lib64/',"$Perms_EX",'815a8b6a4f00526eb606b9404368b60c','NIOS-J86314','ALL'
OnRebootModifyFiles=(
  'libib_dca.so','/usr/lib/fastpath/',"$Perms_RW",'abb96fdfbe0eb63042d44a315deeda74','NIOS-J98885-98886-99096-99097-99099','ALL'
  'fastpath_monitor','/infoblox/one/bin/',"$Perms_EX",'b4821dfe3c4ab1927351d39ca83d9900','NIOS-J98887-98889-98891','ALL'
)

# Files details to add during hotfix apply in runonce
# Format details: 'File name','Directory','Permissions','MD5SUM_REF','Sub Bug ID','Hardware Type'
# eg: 'rebootadd1.py','/infoblox/dns/lib64',"$Perms_EX",'85c367b4097b5c017e32ed9ab9783d54','NIOS-J78065','ALL'
OnRebootAddFiles=(
  'generate_fp_dump','/infoblox/one/bin/',"$Perms_EX",'e2fd4ce2d2d9400fdd161cf9f13c02af','NIOS-J98891','ALL'
)

# Files details to delete during hotfix apply in runonce
# Format details: 'File name','Directory','Sub Bug ID','Hardware Type'
# eg: 'get_count','/infoblox/netmri/bin/','NIOS-J86318','ALL'
OnRebootDeleteFiles=(
)

# Debian package details to install during hotfix apply in runonce
# Format details: 'File name','Common name','Debian package Version','Sub Bug ID', 'Hardware'
# eg: 'deb1-2.0-1.deb','deb1',2,'NIOS-J86319','ALL'
#     'deb2-2.0-1.deb','deb2',2,'NIOS-J86319','ALL'
#     'deb3-2.0-1.deb','deb3',2,'NIOS-J86319','ALL'
OnRebootDEBIANInstall=(
)

# Files details to modify during hotfix apply in execonce
# Format details: 'File name','Directory','Permissions','MD5SUM_REF','Sub Bug ID','Hardware Type'
# eg: 'restartmodify.so','/infoblox/common/lib64/',"$Perms_RW",'c1dcb46b3def79fd0f2d4c8ee4ddc0a6','NIOS-J86316','ALL'
#     'libibutil.so','/infoblox/common/lib64/',"$Perms_RW",'c1dcb46b3def79fd0f2d4c8ee4ddc0a6','NIOS-J86316','ALL'
OnRestartModifyFiles=(
  'monitor','/infoblox/one/bin/',"$Perms_EX",'ae6ffcd47d9c65f1e4ee1fd30035082c','NIOS-J97734-98932','ALL'
  'ib_sensor','/infoblox/one/bin/',"$Perms_EX",'c3218d96adadb1f25f7c366f1b47dfc4','NIOS-J97734','ALL'
  'libibonedb_util.so','/infoblox/one/lib64/',"$Perms_EX",'9542e69a9baa6b2da737331eca399a52','NIOS-J97734-99641','ALL'
  'monitor.pys','/infoblox/one/lib/python/infoblox/one/',"$Perms_RW",'44735c44d7e9adcbf5457176e57a3ac7','NIOS-J97734','ALL'
  'libibrestart_ctrld.so','/infoblox/one/lib64/',"$Perms_EX",'780c7b8600623f9885a841af43b9c3ac','NIOS-J98987','ALL'
  'libibrestart_execd.so','/infoblox/one/lib64/',"$Perms_EX",'d29e77ed9a32b72ddcbcdc83a492634a','NIOS-J98987','ALL'
  'dnssec_common.pys','/infoblox/dns/lib/python/infoblox/dns/',"$Perms_RW",'fed6355e90624d49ab233cb657c4154f','NIOS-J99002','ALL'
  'libibone_safenet.so','/infoblox/one/lib64/',"$Perms_EX",'93f710bcb6b59727d71d99d1b46ef93e','NIOS-J99002','ALL'
  'process_manager_conf.xml','/infoblox/one/etc/',"$Perms_RW",'82bf9a652a8b44a57960980b395c9779','NIOS-J99002','ALL'
  'transfer_support_files','/infoblox/one/bin/',"$Perms_EX",'6e06936c48463685654384d368e742aa','NIOS-J99002','ALL'
  'libibone_rtxml_functions.so','/infoblox/one/lib64/',"$Perms_EX",'77eca73714bfc6386a35ec4871ef5a4b','NIOS-J98830','ALL'
  'libibutil.so','/infoblox/common/lib64/',"$Perms_EX",'75f6a9a7df85af81298425272d64e95f','NIOS-J98907-99641','ALL'
  'named','/usr/sbin/',"$Perms_EX",'f8f32d5648f84fb9838e8fa4a607d793','NIOS-J98005-98822-98907-99381-99910-100113','ALL'
  'serial_console','/infoblox/one/bin/',"$Perms_EX",'1bae56309b35e839e07975a5a77784f5','NIOS-J98897-99641','ALL'
  '_util.so','/infoblox/one/lib/python/infoblox/one/',"$Perms_EX",'59d79d736d31b65fcb6f0a06b9a1b52c','NIOS-J98897-99641','ALL'
  'product_license.pys','/infoblox/one/lib/python/infoblox/one/',"$Perms_RW",'0eec15b019362ef2fc6eef1e62562258','NIOS-J99641','ALL'
)

# Files details to add during hotfix apply in execonce
# Format details: 'File name','Directory','Permissions','MD5SUM_REF','Sub Bug ID','Hardware Type'
# eg: 'restartadd1.py','/infoblox/one/lib/python/infoblox/one',"$Perms_RW",'751459504e372f335de700c375816556','NIOS-J78065','ALL'
OnRestartAddFiles=(
  'rotate_safenet_hsm_cklogs','/infoblox/one/bin/',"$Perms_EX",'fb8d38a4e9ebfe6b3440895897f1f5d8','NIOS-J99002','ALL' 
)

# Files details to delete during hotfix apply in execonce
# Format details: 'File name','Directory','Sub Bug ID','Hardware Type'
# eg: 'restartdel1.py','/infoblox/one/lib/python/infoblox/one','NIOS-J78065','ALL'
OnRestartDeleteFiles=(
)

# Debian package details to install during hotfix apply in execonce
# Format details: 'File name','Common name','Debian package Version','Sub Bug ID', 'Hardware'
# eg: 'deb1-2.0-1.deb','deb1',2,'NIOS-J86319','ALL'
OnRestartDEBIANInstall=(
)

# Binary files that execute during hotfix apply
# Format details: 'File name','Weight','Action to perform','Sub Bug ID','Hardware Type'
# eg: 'execute1.py',10,'Node Restart','NIOS-J786319','ALL'
ExecuteFiles=(
)

# Binary files that execute during restart or after upgrade complete stage
# Format details: 'File name','Weight','Action to perform','Sub Bug ID','Hardware Type'
#eg: 'execute2.py',10,'Node Restart','NIOS-J78060','ALL'
OnPendingExecuteFiles=(
)

# Jira Bugid, if CHF provide master ticket ID.
#eg: JBugID='NIOS-90001'
JBugID='NIOS-98945'

# eg:
#    - CHF hotfix    : CHF-9.0.1.1   HfTag=CHF-9.0.1.1
#    - Custom hotfix : Hotfix-9.0.1  HfTag=Hotfix-9.0.1
#eg: HfTag='CHF-9.0.1.1'
HfTag='CHF-9.0.3.1'

# Set the backup file tag based on the CHF, set the IsCHF to '0' if Custom hotfix.
IsCHF=1
if [ $IsCHF == 1 ]; then
  BackupTag="$HfTag"
else
  BackupTag="$JBugID"
fi

# Set Ignore HF Revert to '1' if there is NO hotfix revert is required for the given hotfix apply.
# By default sets to '0', means hotfix revert is available for the given hotfix apply.
Ignore_HF_Revert=0

# NIOS Version
# eg: Version='9.0.1-49999-eb87c18471a7'
Version='9.0.3-50212-ee11d5834df9'

#Start applying Hotfix
StartHotfix
