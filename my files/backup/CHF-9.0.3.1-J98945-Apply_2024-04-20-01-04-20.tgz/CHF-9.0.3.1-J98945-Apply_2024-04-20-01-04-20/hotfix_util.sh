#!/bin/bash
# Copyright (c) 2024 Infoblox Inc. All Rights Reserved.
##############################################################################
# Hotfix utility for modification/addition/deletion of files
# DEBIANs installations and executing scripts
# 1: Hotfix basic validations
#    - Out of order apply for the CHF version
#    - Invalid Hotfix for CHF version
#    - Avoid installing same hotfix
# 2: Before any operation on the file, validation will be run against each
#    file to proceed or skip if changes are already existing on the nodeps
# 3: Skip DEBIAN installation if already installed on the node.
# 4: Invokes the manifest file generation
#
##############################################################################
source ./hotfix_script.sh

SYSLOG=/usr/bin/logger

ONE_BIN_DIR=/infoblox/one/bin

#Infoblox log macros
IB_LOG="${ONE_BIN_DIR}/ib_log -n $0 -f"

. /infoblox/one/bin/one_common

Perms_EX='755'
Perms_RW='644'

FileOp_Mod="Modified"
FileOp_Add="Added"
FileOp_Del="Deleted"
FileOp_Skip="Skipped"
FileOp_Install="Installed"
FileOp_Execute="Executed"
FileType="file"
FileDEBIAN="debian"
ActionReboot="Appliance reboot"
ActionRestart="Node restart"
ActionUpgrade="Pending on Upgrade"
RestartWeight=10
RebootWeight=100

CHFDIR="/storage/hotfix/chf"
GM_MF_CHFDIR="/storage/hotfix/chf/gm_mf"
MEM_MF_CHFDIR="/storage/hotfix/chf/mem_mf"
HfBackupDir="/storage/hotfix/backup"
TMP_REBOOT_DIR="/storage/hotfix/reboot_files"
TMP_RESTART_DIR="/storage/hotfix/restart_files"
ALT_EXECUTE_PENDING_DIR="/mnt_storage/var/triggers/hf_pending"
FIPS_FLAG_DIR="/storage/etc/fipsmode"
EXEC_ONCE_ON_RESTART_DIR="/storage/var/triggers/product_restart"
EXEC_ONCE_ON_RESTART_FQFILE="/storage/var/triggers/product_restart/exec_once_on_restart"
RUN_ONCE_ON_REBOOT_FQFILE="/etc/rc.d/rc.runonce"
RUN_ONCE_ON_REBOOT_FILE="rc.runonce"
EXEC_ONCE_ON_RESTART_FILE="exec_once_on_restart"
EXEC_ONCE_ON_UPGRADE_FILE="exec_once_on_hf_pending"
MANIFEST_FILE_UTILITY="hotfix_manifest_util"
ROOTFS="/storage/mnt_hf"
CLUSTER_STATUS_FILE="/infoblox/var/cluster_status.txt"

DFAULT_CONF_DIR="/infoblox/one/webgui/default_configuration"
WEBUI_CONF_DIR="/infoblox/var/webgui_conf"
CONF_DIR=$DFAULT_CONF_DIR

function CopyFile {
  # Make sure we're passed 6 arguments
  if [[ $# != 6 ]]; then
    echo "CopyFile was not passed 6 arguments:" | $IB_LOG
    echo "  Args Passed: $*" | $IB_LOG
    return 1
  fi

  # Assign the arguments to variables
  # stripping white space in the process
  Bug=$(echo $1)
  Dir=$(echo $2)
  File=$(echo $3)
  Perms=$(echo $4)
  HardwareType=$(echo $5)
  RunonceMod=$(echo $6)
  
  # Validate the alternate path and set it accordingly
  if [[ "$IsAlternate" == 1 ]]; then
    if [[ "$Dir" == '?/storage/?(*)' ]]; then
      Dir=$alt_storage$Dir
    else
      Dir=$alt_path$Dir
    fi
  fi

  # Make sure none of the variables are empty strings
  if [[ -z "$Bug" || -z "$Dir" || -z "$File" || -z "$Perms" || -z "$HardwareType" || -z "$RunonceMod" ]]; then
    echo "CopyFile: One or more of the arguments passed was empty" | $IB_LOG
    echo "  Bug: $Bug" | $IB_LOG
    echo "  Dir: $Dir" | $IB_LOG
    echo "  File: $File" | $IB_LOG
    echo "  Perms: $Perms" | $IB_LOG
    echo "  HardwareType: $HardwareType" | $IB_LOG
    echo "  RunonceMod: $RunonceMod" | $IB_LOG
    return 1
  fi

  # Make sure hardware checks if needed
  if [[ "$HardwareType" != "ALL" ]]; then
    CheckHardware "$HardwareType" "$File"
    if [ $? != 0 ]; then
      return 2
    fi
  fi 

  # Generate fully qualified original, backup, and new filenames
  FQFile="${Dir}/$File"
  BackupFile="${Dir}/${File}.$Bug"
  NewFile="${Dir}/${File}.new"

  # Make sure not to replace the same files
  # validate new and current md5sum not matches
  if [[ -f $FQFile ]]; then
    if ! ORIGINAL_MD5SUM=$(md5sum $FQFile) 2>&1; then
      echo "md5sum $FQFile failed" | $IB_LOG
      return 1
    else
      ORIGINAL_MD5SUM=$(echo "$ORIGINAL_MD5SUM" | cut -d' ' -f1)
    fi
  else
    echo "failed to find $FQFile" | $IB_LOG
  fi

  if [[ -f ./"$File" ]]; then
    if ! NEW_MD5SUM=$(md5sum ./${File}) 2>&1; then
      echo "md5sum ./$File failed" | $IB_LOG
      return 1
    else
      NEW_MD5SUM=$(echo "$NEW_MD5SUM" | cut -d' ' -f1)
    fi
  else
    echo "failed to find ./$File" | $IB_LOG
    return 1
  fi

  if [[ "$NEW_MD5SUM" && "$ORIGINAL_MD5SUM" ]]; then
     if [[ "$NEW_MD5SUM" == "$ORIGINAL_MD5SUM" ]]; then
       echo "Hotfix: $JBugID md5sum matches, skipping modifying $FQFile" | $IB_LOG
       return 2
     else
       echo "Hotfix: $JBugID md5sum new:$NEW_MD5SUM old:$ORIGINAL_MD5SUM " | $IB_LOG
     fi
  else
    echo "Hotfix: failed to match md5sum new:$NEW_MD5SUM old:$ORIGINAL_MD5SUM" | $IB_LOG
    return 1
  fi

  # Make a backup copy of the file we're going to replace
  # First make sure the original file exists
  if [[ ! -f "$FQFile" ]]; then
    echo "Original file $FQFile does not exist" | $IB_LOG
    return 1
  fi


  # Make sure the backup file does not exist
  if [[ -f "$BackupFile" ]]; then
    echo "Hotfix: $JBugID already applied Backup file $BackupFile exists" | $IB_LOG
    $SYSLOG "Hotfix: $JBugID already applied Backup file ${File}.$Bug exists"
    return 2
  fi

  # Required Validations done, Return back if runonce/execonce
  if [[ "$RunonceMod" != 0 ]]; then
    # Checking md5sums for Reboot/restart files.
    if [ "$NEW_MD5SUM" != "${MD5SUM_REF}" ]; then
      echo "Hotfix: $JBugID failed md5sum miss match with $File" | $IB_LOG
      $SYSLOG "Hotfix: $JBugID failed md5sum miss match with $File"
      return 1
    fi
    echo "Hotfix: $JBugID copying ${File} into runonce or execonce execution" | $IB_LOG
    return 3
  fi

  # Copy the original file to the backup file
  if ! cp -f "$FQFile" "$BackupFile" 2>&1; then
    echo "cp $FQFile $BackupFile failed" | $IB_LOG
    return 1
  fi

  # Copy the new file into the target directory
  # First make sure the updated file exists
  if [[ ! -f ./"$File" ]]; then
    echo "Updated file ./$File does not exist" | $IB_LOG
    # Cleanup by deleting the backup file we just created.
    if ! rm "$BackupFile" 2>&1; then
       echo "rm $BackupFile failed" | $IB_LOG
    fi
    return 1
  fi

  # Make sure the new file does not exist
  if [[ -f "$NewFile" ]]; then
    echo "New File $NewFile exists" | $IB_LOG
    # Cleanup by deleting the backup file we just created.
    if ! rm "$BackupFile" 2>&1; then
       echo "rm $BackupFile failed" | $IB_LOG
    fi
    return 1
  fi

  # Copy the new file into the target directory
  if ! cp -f ./"$File" "$NewFile" 2>&1; then
    echo "cp ./$File $NewFile failed" | $IB_LOG
    # Cleanup by deleting the backup file we just created.
    if ! rm "$BackupFile" 2>&1; then
       echo "rm $BackupFile failed" | $IB_LOG
    fi
    return 1
  fi

  # Make sure md5sum matches after copying the new file
  # Get current md5sum for new file
  if ! CURRENT_MD5SUM=$(md5sum "${NewFile}" | cut -d' ' -f1) 2>&1; then
    echo "md5sum $NewFile failed" | $IB_LOG
    # Cleanup by deleting the backup and the new file we just created.
    if ! rm "$NewFile" 2>&1; then
      echo "rm "$NewFile" failed" | $IB_LOG
    fi
    if ! rm "$BackupFile" 2>&1; then
       echo "rm $BackupFile failed" | $IB_LOG
    fi
    return 1
  fi

  if [ "$CURRENT_MD5SUM" != "${MD5SUM_REF}" ]; then
    echo "Hotfix: $JBugID failed md5sum miss match after copy new $NewFile" | $IB_LOG
    $SYSLOG "Hotfix: $JBugID failed md5sum miss match after copy new $NewFile"
    # Cleanup by deleting the backup and the new file we just created.
    if ! rm "$NewFile" 2>&1; then
      echo "rm "$NewFile" failed" | $IB_LOG
    fi
    if ! rm "$BackupFile" 2>&1; then
       echo "rm $BackupFile failed" | $IB_LOG
    fi
    return 1
  fi

  # Make sure the permissions are set correctly on the new file
  if ! chmod "$Perms" "$NewFile" 2>&1; then
    echo "chmod $Perms $NewFile failed" | $IB_LOG
    # Cleanup by deleting the backup and the new file we just created.
    if ! rm "$NewFile" 2>&1; then
      echo "rm $NewFile failed" | $IB_LOG
    fi
    if ! rm "$BackupFile" 2>&1; then
       echo "rm $BackupFile failed" | $IB_LOG
    fi
    return 1
  fi

  # Replace the old file with the new one
  if ! mv -f "$NewFile" "$FQFile" 2>&1; then
    echo "mv $NewFile $FQFile failed" | $IB_LOG
    # Cleanup by deleting the backup and the new file we just created.
    if ! rm "$NewFile" 2>&1; then
      echo "rm $NewFile failed" | $IB_LOG
    fi
    if ! rm "$BackupFile" 2>&1; then
       echo "rm $BackupFile failed" | $IB_LOG
    fi
    return 1
  else
    echo "Hotfix: $JBugID modified $File success." | $IB_LOG
  fi

  # All is good
  return 0
}

function ModifyFiles {
  # Modify existing file
  for i in ${!ModifyFiles[@]}; do
    RevertFileIndex=i
    EachFile=${ModifyFiles[i]}
    File=$(echo $EachFile | cut -d ',' -f1)
    DirPath=$(echo $EachFile | cut -d ',' -f2)
    Perm=$(echo $EachFile | cut -d ',' -f3)
    Weight=$(echo $EachFile | cut -d ',' -f4)
    Action=$(echo $EachFile | cut -d ',' -f5)
    MD5SUM_REF=$(echo $EachFile | cut -d ',' -f6)
    SubBugID=$(echo $EachFile | cut -d ',' -f7)
    HardwareType=$(echo $EachFile | cut -d ',' -f8)

    # If Dir is not ending with '/', then add it
    if [[ ${DirPath: -1} != "/" ]]; then
      DirPath=$DirPath/
    fi

    # Trigger copy	
    CopyFile "$BackupTag" "$DirPath" "$File" "$Perm" "$HardwareType" 0
    ReturnCode=$?
    if [ "$ReturnCode" != 0 ] && [ "$ReturnCode" != 2 ]; then
      # Execute LogMessages_RevertBack
      echo "Hotfix: $JBugID failed in applying $File file revert back applied changes." | $IB_LOG
      $SYSLOG "Hotfix: $JBugID failed in applying $File file revert back applied changes."
      LogMessages_RevertBack_All
    else
      GenerateCSVfile "$DirPath$File" "$Weight" "$Action" "$CsvFile" "$ReturnCode" "$FileOp_Mod" "$FileType"
    fi
  done
}


function AddFile {
  # Make sure we're passed 6 arguments
  if [[ $# != 6 ]]; then
    echo "AddFile was not passed 6 arguments:" | $IB_LOG
    echo "  Args Passed: $*" | $IB_LOG
    return 1
  fi

  # Assign the arguments to variables
  # stripping white space in the process
  Bug=$(echo $1)
  Dir=$(echo $2)
  File=$(echo $3)
  Perms=$(echo $4)
  HardwareType=$(echo $5)
  RunonceAdd=$(echo $6)

  # Make sure none of the variables are empty strings
  if [[ -z "$Bug" || -z "$Dir" || -z "$File" || -z "$Perms" || -z "$HardwareType" || -z "$RunonceAdd" ]]; then
    echo "AddFile: One or more of the arguments passed was empty" | $IB_LOG
    echo "  Bug: $Bug" | $IB_LOG
    echo "  Dir: $Dir" | $IB_LOG
    echo "  File: $File" | $IB_LOG
    echo "  Perms: $Perms" | $IB_LOG
    echo "  HardwareType: $HardwareType" | $IB_LOG
    echo "  RunonceAdd: $RunonceAdd" | $IB_LOG
    return 1
  fi

  # Validate the alternate path and set it accordingly
  if [[ "$IsAlternate" == 1 ]]; then
    if [[ $Dir == '?/$Dir/?(*)' ]]; then
      Dir="$alt_storage$Dir"
    else
      Dir="$alt_path$Dir"
    fi
  fi

  # Make sure hardware checks if needed
  if [[ "$HardwareType" != "ALL" ]]; then
    CheckHardware "$HardwareType" "$File"
    if [ $? != 0 ]; then
      return 2
    fi
  fi 
  
  # Generate fully qualified original, backup, and new filenames
  FQFile="${Dir}/$File"
  BackupFile="${Dir}/${File}.$Bug"
  NewFile="${Dir}/${File}.new"

  # Make sure the latest newly introduced file does not exist
  if [[ -f "$FQFile" ]]; then
    echo "Hotfix: $JBugID already applied Backup file $FQFile exists" | $IB_LOG
    $SYSLOG "Hotfix: $JBugID already applied Backup file ${File}.$Bug exists"
    return 2
  fi

  # First make sure the updated file exists
  if [[ ! -f ./"$File" ]]; then
    echo "Updated file ./$File does not exist" | $IB_LOG
    return 1
  fi

  # Make sure the new file does not exist
  if [[ -f "$NewFile" ]]; then
    echo "New File $NewFile exists" | $IB_LOG
    return 1
  fi

  # Required Validations done, Return back if runonce/execonce
  if [[ "$RunonceAdd" != 0 ]]; then
    echo "Hotfix: $JBugID add ${File} into runonce or execonce execution" | $IB_LOG
    return 3
  fi

  # Copy the new file into the target directory
  if ! cp -f ./"$File" "$NewFile" 2>&1; then
    echo "cp ./$File $NewFile failed" | $IB_LOG
    return 1
  fi

  # Make sure the permissions are set correctly on the new file
  if ! chmod "$Perms" "$NewFile" 2>&1; then
    echo "chmod $Perms $NewFile failed" | $IB_LOG

    # Cleanup by deleting the new file
    if ! rm "$NewFile" 2>&1; then
      echo "rm $NewFile failed" | $IB_LOG
    fi
    return 1
  fi

  # Replace the new file to target
  if ! mv -f "$NewFile" "$FQFile" 2>&1; then
    echo "mv $NewFile $FQFile failed" | $IB_LOG
    return 1
  else
    echo "Hotfix: $JBugID Added $File success." | $IB_LOG
  fi
  
  # Make sure the backup directory exists
  if [[ ! -d "$HfBackupDir" ]]; then
    echo "Creating dir $HfBackupDir for backup" | $IB_LOG
    mkdir -p "$HfBackupDir"
  fi

  # Copy the original file to the backup file, this will be
  # removed during cleanup
  if ! cp -f "$FQFile" "$HfBackupDir"/ 2>&1; then
    echo "Add copy $FQFile failed" | $IB_LOG
    return 1
  fi

  # All is good
  return 0
}

function AddFiles {
  # modify the files
  SuccessCopy=0
  # Modify existing file or Add a new file
  for i in ${!AddedFiles[@]}; do
    RevertFileIndex=i
    EachFile=${AddedFiles[i]}
    File=$(echo $EachFile | cut -d ',' -f1)
    DirPath=$(echo $EachFile | cut -d ',' -f2)
    Perm=$(echo $EachFile | cut -d ',' -f3)
    Weight=$(echo $EachFile | cut -d ',' -f4)
    Action=$(echo $EachFile | cut -d ',' -f5)
    MD5SUM_REF=$(echo $EachFile | cut -d ',' -f6)
    SubBugID=$(echo $EachFile | cut -d ',' -f7)
    HardwareType=$(echo $EachFile | cut -d ',' -f8)

    # If Dir is not ending with '/', then add it
    if [[ ${DirPath: -1} != "/" ]]; then
      DirPath=$DirPath/
    fi

    # Trigger copy
    AddFile $BackupTag $DirPath $File $Perm $HardwareType 0
    ReturnCode=$?

    if [ $ReturnCode != 0 ] && [ $ReturnCode != 2 ]; then
      # Execute RevertBack
      echo "Hotfix: $JBugID failed in adding $File revert back applied changes." | $IB_LOG
      $SYSLOG "Hotfix: $JBugID failed in adding $File revert back applied changes."
      LogMessages_RevertBack_All
    else
      GenerateCSVfile $DirPath$File $Weight "$Action" $CsvFile $ReturnCode $FileOp_Add $FileType
    fi
  done
}


function DeleteFile {
  # Make sure we're passed 4 arguments
  if [[ $# != 4 ]]; then
    echo "DeleteFile was not passed 4 arguments:" | $IB_LOG
    echo "  Args Passed: $*" | $IB_LOG
    return 1
  fi

  # Assign the arguments to variables
  # stripping white space in the process
  Dir=$(echo $1)
  File=$(echo $2)
  HardwareType=$(echo $3)
  RunonceDel=$(echo $4)

  # Validate the alternate path and set it accordingly
  if [[ $IsAlternate == 1 ]]; then
    if [[ $Dir == '?/$Dir/?(*)' ]]; then
      Dir=$alt_storage$Dir
    else
      Dir=$alt_path$Dir
    fi
  fi
  
  # Make sure none of the variables are empty strings
  if [[ -z $Dir || -z $File || -z $HardwareType ]]; then
    echo "  Dir: $Dir" | $IB_LOG
    echo "  File: $File" | $IB_LOG
    echo "  HardwareType: $HardwareType" | $IB_LOG
    return 1
  fi

  # Make sure hardware checks if needed
  if [[ $HardwareType != "ALL" ]]; then
    CheckHardware $HardwareType $File
    if [ $? != 0 ]; then
      return 2
    fi
  fi 

  # Generate fully qualified original, backup, and new filenames
  FQFile="${Dir}/$File"

  # Check for the original file exists, this file may got deleted by the previous CHF.
  # Log and mark as skipped
  if [[ ! -f $FQFile ]]; then
    echo "Hotfix: $JBugID $FQFile already deleted." | $IB_LOG
    return 2
  fi

  # Required Validations done, Return back if runonce/execonce
  if [[ $RunonceDel != 0 ]]; then
    echo "Hotfix: $JBugID Delete ${File} into runonce or execonce execution" | $IB_LOG
    return 3
  fi

  # Make sure the the backup directory exists
  if [[ ! -d "$HfBackupDir" ]]; then
    echo "Hotfix: Creating dir $HfBackupDir for backup" | $IB_LOG
    mkdir -p $HfBackupDir
  fi

  # Copy the original file to the backup file
  if ! cp -f "$FQFile" "$HfBackupDir"/ 2>&1; then
    echo "Delete copy $FQFile $BackupFile failed" | $IB_LOG
    return 1
  fi

  # Delete the file.
  if ! rm "$FQFile" 2>&1; then
    echo "rm  $FQFile failed" | $IB_LOG
    return 1
  fi
}

function DeleteFiles {
  # modify the files
  SuccessCopy=0
  # Modify existing file or Add new file
  for i in ${!DeletedFiles[@]}; do
    RevertFileIndex=i
    EachFile=${DeletedFiles[i]}
    File=$(echo $EachFile | cut -d ',' -f1)
    DirPath=$(echo $EachFile | cut -d ',' -f2)
    Weight=$(echo $EachFile | cut -d ',' -f3)
    Action=$(echo $EachFile | cut -d ',' -f4)
    SubBugID=$(echo $EachFile | cut -d ',' -f5)
    HardwareType=$(echo $EachFile | cut -d ',' -f6)

    # If Dir is not ending with '/', then add it
    if [[ ${DirPath: -1} != "/" ]]; then
      DirPath=$DirPath/
    fi

    # Trigger Delete
    DeleteFile $DirPath $File $HardwareType 0
    ReturnCode=$?

    if [ $ReturnCode != 0 ] && [ $ReturnCode != 2 ]; then
      # Execute RevertBack
      echo "Hotfix: $JBugID failed in deleting $File revert back applied changes." | $IB_LOG
      $SYSLOG "Hotfix: $JBugID failed in deleting $File revert back applied changes."
      LogMessages_RevertBack_All
    else
      GenerateCSVfile $DirPath$File $Weight "$Action" $CsvFile $ReturnCode $FileOp_Del $FileType
    fi
  done
}

function CopyExeconce {
  # Copy execonce, skip if FIPS enabled
  # Need execonce for executing scripts during restart

  # Make sure we're passed 1 arguments
  if [[ $# != 1 ]]; then
    echo "CopyExeconce was not passed 1 arguments:" | $IB_LOG
    echo "  Args Passed: $*" | $IB_LOG
    return 1
  fi

  # Assign the arguments to variables
  # stripping white space in the process
  OnlyExecutables=$(echo $1)
 
  # Make sure none of the variables are emtpy strings
  if [[ -z $OnlyExecutables ]]; then
    echo "  OnlyExecutables: $OnlyExecutables" | $IB_LOG
    return 1
  fi

  if [[ -f ./$EXEC_ONCE_ON_RESTART_FILE ]]; then
    if [[ ! -d $FIPS_FLAG_DIR && $CP_EXEC_HF_PENDING != 1 ]]; then
      echo "Hotfix: $JBugID copying exec_once_on_restart" | $IB_LOG
      # Copy the original file to the backup file
      if ! cp -f ./$EXEC_ONCE_ON_RESTART_FILE $EXEC_ONCE_ON_RESTART_FQFILE 2>&1; then
        echo "Hotfix: $JBugID cp ./$EXEC_ONCE_ON_RESTART_FILE $EXEC_ONCE_ON_RESTART_FQFILE failed" | $IB_LOG
        LogMessages_RevertBack_All
        exit 1
      fi
    elif [[ $OnlyExecutables == 1 && -d $FIPS_FLAG_DIR ]]; then
      # Copy the execonce, runs only the executables present in the EXEC_ONCE_ON_RESTART_DIR
      # Note: At this stage no files operations should be done(eg:modify,add,delete)
      # FIPS integrity check will fail if we modify during the execonce
      if ! cp -f ./$EXEC_ONCE_ON_RESTART_FILE $EXEC_ONCE_ON_RESTART_FQFILE 2>&1; then
        echo "Hotfix: $JBugID cp ./$EXEC_ONCE_ON_RESTART_FILE $EXEC_ONCE_ON_RESTART_FQFILE failed" | $IB_LOG
        LogMessages_RevertBack_All
        exit 1
      fi
    elif [[ $CP_EXEC_HF_PENDING == 1 ]]; then
      # Copy the exec_once_on_hf_pending to hf_pending dir as exec_once_on_restart
      CopyPendingonce	  
    else
      echo "Hotfix: $JBugID ./$EXEC_ONCE_ON_RESTART_FILE skipped due to FIPS enabled" | $IB_LOG
    fi
    if [[ -f $EXEC_ONCE_ON_RESTART_FQFILE ]]; then
      chmod a+rx $EXEC_ONCE_ON_RESTART_FQFILE
    fi
  else
    echo "Hotfix: $JBugID ./$EXEC_ONCE_ON_RESTART_FILE doesn't exist! now exiting" | $IB_LOG
    LogMessages_RevertBack_All
    exit 1
  fi
}

function CopyPendingonce {
# Copy the exec_once_on_hf_pending script as exec_once_on_restart to reuse the run_once_dir sequence.
if [[ -d $ALT_EXECUTE_PENDING_DIR ]]; then
  if [[ -f "$EXEC_ONCE_ON_UPGRADE_FILE" ]]; then
    if ! cp -f ./"$EXEC_ONCE_ON_UPGRADE_FILE" $ALT_EXECUTE_PENDING_DIR/$EXEC_ONCE_ON_RESTART_FILE 2>&1; then
      echo "Hotfix: $JBugID failed in copying $EXEC_ONCE_ON_UPGRADE_FILE file to $ALT_EXECUTE_PENDING_DIR." | $IB_LOG
    else
      chmod a+rx "$ALT_EXECUTE_PENDING_DIR/$EXEC_ONCE_ON_RESTART_FILE"
      echo "Hotfix: $JBugID file $EXEC_ONCE_ON_UPGRADE_FILE copied to $ALT_EXECUTE_PENDING_DIR" | $IB_LOG
    fi
  fi
else
  echo "Hotfix: $JBugID failed no Dir $ALT_EXECUTE_PENDING_DIR" | $IB_LOG
fi
}

function CopyRunonce {
  mkdir -p $ROOTFS
  if [[ -f ./$RUN_ONCE_ON_REBOOT_FILE ]] ; then
    echo "Hotfix: $JBugID copying rc.runonce" | $IB_LOG
    mount --bind / $ROOTFS
    # Copy the original file to the backup file
    if ! cp -f ./$RUN_ONCE_ON_REBOOT_FILE "$ROOTFS"/$RUN_ONCE_ON_REBOOT_FQFILE 2>&1; then
      echo "Hotfix: $JBugID cp ./$RUN_ONCE_ON_REBOOT_FILE $RUN_ONCE_ON_REBOOT_FQFILE failed" | $IB_LOG
      LogMessages_RevertBack_All
      exit 1
    fi
    chmod $Perms_EX "$ROOTFS"/$RUN_ONCE_ON_REBOOT_FQFILE
    umount -l $ROOTFS
  else
    echo "Hotfix: $JBugID ./$RUN_ONCE_ON_REBOOT_FILE doesn't exist! now exiting" | $IB_LOG
    LogMessages_RevertBack_All
    exit 1
  fi
}

# Based on the active partition runonce should execute else directly apply on the alternate partition. 
function RunonceFiles {
  # Update the files in runonce based on the operations
  # Modify
  RunonceFilesModify

  # Add
  RunonceFilesAdd

  # Delete
  RunonceFilesDelete

  # DEBIANs
  RunonceDEBIANS

  # Copy runonce into FQ runonce path
  if [[ $NeedRunonce == 1 ]]; then
    CopyRunonce
  fi
}


function CopyFilesRRTmpDir {
  # Make sure we're passed 3 arguments
  if [[ $# != 3 ]]; then
    $SYSLOG "Failed in CopyFilesRRTmpDir was not passed 1 argument, Args Passed: $*"
    echo "Failed in CopyFilesRRTmpDir was not passed 1 argument" | $IB_LOG
    echo "Args Passed: $*" | $IB_LOG
    LogMessages_RevertBack_All
    exit 1
  fi

  CpFile=$1
  TmpDir=$2
  Proc=$3

  if [ ! -d ${TMP_REBOOT_DIR} ] && [ $Proc == "runonce" ]; then
    mkdir -p $TMP_REBOOT_DIR
  fi

  if [ ! -d ${TMP_RESTART_DIR} ] && [ $Proc == "execonce" ]; then
    mkdir -p $TMP_RESTART_DIR
  fi

  if [ -d $TmpDir ]; then
    if ! cp ./$CpFile $TmpDir/ 2>&1; then
      echo "Hotfix: $JBugID failed cp ./$CpFile" | $IB_LOG
      LogMessages_RevertBack_All
    else
      echo "Hotfix: $JBugID $CpFile pending during $Proc" | $IB_LOG
      # Based on the TmpDir set runonce or execonce file needs to be copied.
      # At this point we need runonce or execonce
      if [[ "$TmpDir" == "$TMP_REBOOT_DIR" ]]; then
        NeedRunonce=1
      else
        NeedExeconce=1
      fi
    fi
  else
    echo "Hotfix: $JBugID $TmpDir not found" | $IB_LOG
    LogMessages_RevertBack_All
  fi
}

function RunonceFilesModify {
  NeedRunonce=0
  # Update the files in runonce csv after validations
  for i in ${!OnRebootModifyFiles[@]}; do
    RevertFileIndex=i
    EachFile=${OnRebootModifyFiles[i]}
    FileModify=$(echo $EachFile | cut -d ',' -f1)
    DirPath=$(echo $EachFile | cut -d ',' -f2)
    Perm=$(echo $EachFile | cut -d ',' -f3)
    MD5SUM_REF=$(echo $EachFile | cut -d ',' -f4)
    SubBugID=$(echo $EachFile | cut -d ',' -f5)
    HardwareType=$(echo $EachFile | cut -d ',' -f6)

    # If Dir is not ending with '/', then add it
    if [[ ${DirPath: -1} != "/" ]]; then
      DirPath=$DirPath/
    fi

    # Validate files
    if [[ $IsActive == 1 ]]; then
      CopyFile $BackupTag $DirPath $FileModify $Perm $HardwareType 1
    else
      CopyFile $BackupTag $DirPath $FileModify $Perm $HardwareType 0
    fi
    ReturnCode=$?
    if [[ $ReturnCode == 0 ]]; then
      # Alternate partition copy success
      # Update CSV file with the modified status
      GenerateCSVfile $DirPath$FileModify $RebootWeight "$ActionReboot" $CsvFile $ReturnCode $FileOp_Mod $FileType
    elif [[ $ReturnCode == 1 ]]; then
      # Execute LogMessages_RevertBack
      echo "Hotfix: $JBugID failed in applying $FileModify file revert back applied changes." | $IB_LOG
      $SYSLOG "Hotfix: $JBugID failed in applying $FileModify file revert back applied changes."
      LogMessages_RevertBack_All
    elif [[ $ReturnCode == 2 ]]; then
      # Update CSV file with skipped status
      GenerateCSVfile $DirPath$FileModify $RebootWeight "$ActionReboot" $CsvFile $ReturnCode $FileOp_Mod $FileType
    elif [[ $ReturnCode == 3 ]]; then
      # Update CSV file as action modify, during reboot modification will be triggered
      GenerateCSVfile $DirPath$File $RebootWeight "$ActionReboot" $CsvFile $ReturnCode $FileOp_Mod $FileType
      CopyFilesRRTmpDir $FileModify $TMP_REBOOT_DIR "runonce"
    else
      echo "Hotfix: $JBugID failed unexpected return code:$ReturnCode. Revert back applied changes" | $IB_LOG
      LogMessages_RevertBack_All
    fi
  done  
}

function RunonceFilesAdd {
  # Add the files in runonce csv after validations
  for i in ${!OnRebootAddFiles[@]}; do
    RevertFileIndex=i
    EachFile=${OnRebootAddFiles[i]}
    FileAd=$(echo $EachFile | cut -d ',' -f1)
    DirPath=$(echo $EachFile | cut -d ',' -f2)
    Perm=$(echo $EachFile | cut -d ',' -f3)
    MD5SUM_REF=$(echo $EachFile | cut -d ',' -f4)
    SubBugID=$(echo $EachFile | cut -d ',' -f5)
    HardwareType=$(echo $EachFile | cut -d ',' -f6)

    # If Dir is not ending with '/', then add it
    if [[ ${DirPath: -1} != "/" ]]; then
      DirPath=$DirPath/
    fi

    # Validate files
    if [[ $IsActive == 1 ]]; then
      AddFile $BackupTag $DirPath $FileAd $Perm $HardwareType 1
    else
      AddFile $BackupTag $DirPath $FileAd $Perm $HardwareType 0
    fi

    ReturnCode=$?
    if [[ $ReturnCode == 0 ]]; then
      # Alternate partition add success
      GenerateCSVfile $DirPath$FileAd $RebootWeight "$ActionReboot" $CsvFile $ReturnCode $FileOp_Add $FileType
    elif [[ $ReturnCode == 1 ]]; then
      # Execute LogMessages_RevertBack
      echo "Hotfix: $JBugID failed in applying $FileAd file revert back applied changes." | $IB_LOG
      $SYSLOG "Hotfix: $JBugID failed in applying $FileAd file revert back applied changes."
      LogMessages_RevertBack_All
    elif [[ $ReturnCode == 2 ]]; then
      # Update CSV file with skipped status
      GenerateCSVfile $DirPath$FileAd $RebootWeight "$ActionReboot" $CsvFile $ReturnCode $FileOp_Add $FileType
    elif [[ $ReturnCode == 3 ]]; then
      # Default consider reboot needed
      GenerateCSVfile $DirPath$FileAd $RebootWeight "$ActionReboot" $CsvFile $ReturnCode $FileOp_Add $FileType
      CopyFilesRRTmpDir $FileAd $TMP_REBOOT_DIR "runonce"
    else
      echo "Hotfix: $JBugID failed unexpected return code:$ReturnCode. Revert back applied changes" | $IB_LOG
      LogMessages_RevertBack_All
    fi
  done
}

function RunonceFilesDelete {
  # Delete the files in runonce csv after validations
  for i in ${!OnRebootDeleteFiles[@]}; do
    RevertFileIndex=i
    EachFile=${OnRebootDeleteFiles[i]}
    FileDel=$(echo $EachFile | cut -d ',' -f1)
    DirPath=$(echo $EachFile | cut -d ',' -f2)
    SubBugID=$(echo $EachFile | cut -d ',' -f3)
    HardwareType=$(echo $EachFile | cut -d ',' -f4)

    # If Dir is not ending with '/', then add it
    if [[ ${DirPath: -1} != "/" ]]; then
      DirPath=$DirPath/
    fi

    # Validate files
    if [[ $IsActive == 1 ]]; then
      DeleteFile $DirPath $FileDel $HardwareType 1
    else
      DeleteFile $DirPath $FileDel $HardwareType 0
    fi
    ReturnCode=$?
    if [[ $ReturnCode == 0 ]]; then
      # Alternate partition delete success
      GenerateCSVfile $DirPath$FileDel $RebootWeight "$ActionReboot" $CsvFile $ReturnCode $FileOp_Del $FileType
    elif [[ $ReturnCode == 1 ]]; then
      # Execute LogMessages_RevertBack
      echo "Hotfix: $JBugID failed in applying $FileDel file revert back applied changes." | $IB_LOG
      $SYSLOG "Hotfix: $JBugID failed in applying $FileDel file revert back applied changes."
      LogMessages_RevertBack_All
    elif [[ $ReturnCode == 2 ]]; then
      # Update CSV file with skipped status
      GenerateCSVfile $DirPath$FileDel $RebootWeight "$ActionReboot" $CsvFile $ReturnCode $FileOp_Del $FileType
    elif [[ $ReturnCode == 3 ]]; then
      # Update CSV file with pending action
      # Default consider reboot needed
      GenerateCSVfile $DirPath$FileDel $RebootWeight "$ActionReboot" $CsvFile $ReturnCode $FileOp_Del $FileType
      NeedRunonce=1
    else
      echo "Hotfix: $JBugID failed unexpected return code:$ReturnCode. Revert back applied changes" | $IB_LOG
      LogMessages_RevertBack_All
    fi
  done
}

function RunonceDEBIANS {
  # Make sure not to install already installed DEBIANs
  
  for i in ${!OnRebootDEBIANInstall[@]}; do
    RevertFileIndex=i
    EachFile=${OnRebootDEBIANInstall[i]}
    DEBIANName=$(echo $EachFile | cut -d ',' -f1)
    CName=$(echo $EachFile | cut -d ',' -f2)
    CVersion=$(echo $EachFile | cut -d ',' -f3)
    SBugID=$(echo $EachFile | cut -d ',' -f4)
    HardwareType=$(echo $EachFile | cut -d ',' -f5)
        
    #Validate DEBIAN needs to be installed
    CheckDEBIANInstall $CName $CVersion $HardwareType
    ReturnCodeDEBIAN=$?
    if [[ $ReturnCodeDEBIAN == 0 || $ReturnCodeDEBIAN == 2 || $ReturnCodeDEBIAN == 8 ]]; then
      CDEBIANName="${CName}:${CVersion}:${DEBIANName}"
      CopyDEBIANTmpDIR $DEBIANName $ReturnCodeDEBIAN "${CDEBIANName}" $TMP_REBOOT_DIR $RebootWeight "${ActionReboot}"	
    else
      echo "Hotfix: $JBugID failed fetching DEBIAN validation: $ReturnCodeDEBIAN" | $IB_LOG
      LogMessages_RevertBack_All
    fi
  done
}

function CopyDEBIANTmpDIR {
  # Make sure we're passed 6 arguments
  if [[ $# != 6 ]]; then
    echo "CopyDEBIANTmpDIR was not passed 6 arguments:" | $IB_LOG
    echo "  Args Passed: $*" | $IB_LOG
    return 1
  fi

  # Assign the arguments to variables
  # stripping white space in the process
  RName=$(echo $1)
  RC=$(echo $2)
  CRName=$(echo $3)
  TmpDir=$(echo $4)
  TmpWeight=$(echo $5)
  TmpAction=$(echo $6)

  # Generate the temporary input CSV file for runonce script during the reboot
  if [ ! -d $TmpDir ] && [ "$RC" == 0 ] && [ $IsActive == 1 ]; then
    mkdir -p $TmpDir
  fi

  if [ $RC == 0 ]; then
    if [[ $IsActive == 1 ]]; then
      if [ -d $TmpDir ]; then
        if ! cp ./$RName $TmpDir/ 2>&1; then
          echo "Hotfix: $JBugID failed cp ./$RName" | $IB_LOG
          LogMessages_RevertBack_All
        else
          echo "Hotfix: $JBugID $RName pending during runonce" | $IB_LOG
          # Update CSV file with a pending action
          # Default consider reboot needed
          GenerateCSVfile "${CRName}" $TmpWeight "$TmpAction" $CsvFile $RC $FileOp_Install $FileDEBIAN
          # Based on the TmpDir set runonce or execonce file needs to be copied.
          # At this point we need runonce or execonce
          if [[ "$TmpDir" == "$TMP_REBOOT_DIR" ]]; then
            NeedRunonce=1
          else
            NeedExeconce=1
          fi
        fi
      else
        echo "Hotfix: $JBugID $TmpDir not found" | $IB_LOG
        LogMessages_RevertBack_All
      fi
    else
      # Install DEBIAN on an alternate partition
      InstallDEBIANAlt $RName
      GenerateCSVfile "${CRName}" $TmpWeight "$TmpAction" $CsvFile $RC $FileOp_Install $FileDEBIAN 
    fi
  elif [[ $RC == 2 || $RC == 8 ]]; then
    # Skip: DEBIAN already installed or hardware check miss match
    RC_ALT=2
    GenerateCSVfile "${CRName}" $TmpWeight "$TmpAction" $CsvFile $RC_ALT $FileOp_Install $FileDEBIAN
  else
    echo "Hotfix: $JBugID CopyDEBIANTmpDIR: Failed unknown $RC " | $IB_LOG
    LogMessages_RevertBack_All
  fi
}

function InstallDEBIANAlt {
  #This should be changed, debian installation options may vary
  RNAME=$(echo $1)
  if [[ -z $RNAME ]]; then
    echo "InstallDEBIANAlt: One or more of the arguments passed was empty" | $IB_LOG
    echo "  RNAME: $RNAME" | $IB_LOG
    return 1
  fi
  #Install DEBIAN on alternate partition directly
  echo "Hotfix: $JBugID Start Installing the debian $RNAME on an alternate partition." | $IB_LOG
  # Make root partition to read-write, since debian tries to update the debian db
  /infoblox/one/bin/mount_root_partition_rw
  dpkg --force-depends --root="$alt_path/" -i "./$RNAME" 2>&1 | $IB_LOG
  /infoblox/one/bin/mount_root_partition_ro
  echo "Hotfix: $JBugID  Done Installing the debian $RNAME on an alternate partition." | $IB_LOG
}

function CheckDEBIANInstall {
  # Make sure not to install already installed hotfix
  # Validate the hw_type before proceeding

  # Make sure we're passed 3 arguments
  if [[ $# != 3 ]]; then
    echo "CheckDEBIANInstall was not passed 3 arguments:" | $IB_LOG
    echo "  Args Passed: $*" | $IB_LOG
    return 1
  fi

  # Assign the arguments to variables
  # stripping white space in the process
  CName=$(echo $1)
  CVersion=$(echo $2)
  HardwareType=$(echo $3)

  # Make sure hardware checks if needed
  if [[ $HardwareType != "ALL" ]]; then
    CheckHardware $HardwareType $File
    if [ $? != 0 ]; then
      return 2
    fi
  fi 

  result=`./$MANIFEST_FILE_UTILITY --validate debian_install  --hf_version $HfTag --debian_cname $CName --debian_version $CVersion --bugid $JBugID --nios_version $Version`
  ParseRcResult "$result"
  return $RC
}

function GetFIPSVal {
  # Based on FIPS return the Tmp Dir
  SWITCHRUNONCE=0
  if [[ -d $FIPS_FLAG_DIR ]]; then
    # FIPS execute all files during restart from runonce
    echo "Hotfix: $JBugID Move all execonce to runonce due FIPS enabled" | $IB_LOG
    TMPDIR=$TMP_REBOOT_DIR
    TMPWEIGHT=$RebootWeight
    TMPACTION=$ActionReboot
    TMPOP="runonce"
    SWITCHRUNONCE=1
  else
    TMPDIR=$TMP_RESTART_DIR
    TMPWEIGHT=$RestartWeight
    TMPACTION=$ActionRestart
    TMPOP="execonce"
    SWITCHRUNONCE=0
  fi
}

function ExecuteFiles {
  # Execute files directly on the node if the Active partition
  for i in ${!ExecuteFiles[@]}; do
    EachFile=${ExecuteFiles[i]}
    FileEx=$(echo $EachFile | cut -d ',' -f1)
    Weight=$(echo $EachFile | cut -d ',' -f2)
    Action=$(echo $EachFile | cut -d ',' -f3)
    SubBugID=$(echo $EachFile | cut -d ',' -f4)
    HardwareType=$(echo $EachFile | cut -d ',' -f5)

    # Validate files
    if [[ "$IsActive" == 1 ]]; then
      # copy the executables to the backup directory and execute and remove.
      ExecuteFile "$FileEx" "$SubBugID" "$HardwareType" "$HfBackupDir" 0
      ReturnCode=$?
    else
      # If not active partition copy the executables to the pending directory, execute after upgrade.
      echo "Hotfix: $JBugID node is in distribution complete stage,Pending: $FileEx will execute during upgrade" | $IB_LOG
      ExecuteFile "$FileEx" "$SubBugID" "$HardwareType" "$ALT_EXECUTE_PENDING_DIR" 1
      ReturnCode=$?
      if [ "$ReturnCode" == 3 ]; then
        CP_EXEC_HF_PENDING=1
      fi
    fi

    if [ $ReturnCode == 1 ]; then
      # LogMessage on failure
      echo "Hotfix: $JBugID failed in executing $FileEx." | $IB_LOG
      LogMessages_RevertBack_All
      exit 1
    else
      GenerateCSVfile $FileEx $RestartWeight "$Action" $CsvFile $ReturnCode $FileOp_Execute $FileType
    fi
  done 
}

function ExecuteFiles_Pending {
  # Update the files in below dir after validations
  #  - '/storage/var/triggers/product_restart'
  #  - '/storage/var/triggers/hf_pending/'
  Executables=0
  for i in ${!OnPendingExecuteFiles[@]}; do
    EachFile=${OnPendingExecuteFiles[i]}
    FileEx=$(echo $EachFile | cut -d ',' -f1)
    Weight=$(echo $EachFile | cut -d ',' -f2)
    Action=$(echo $EachFile | cut -d ',' -f3)
    SubBugID=$(echo $EachFile | cut -d ',' -f4)
    HardwareType=$(echo $EachFile | cut -d ',' -f5)

    # Validate files
    if [[ $IsActive == 1 ]]; then
      # Execute the file during product restart
      ExecuteFile $FileEx $SubBugID $HardwareType $EXEC_ONCE_ON_RESTART_DIR 1
      ReturnCode=$?
      if [ $ReturnCode == 3 ]; then
        Executables=1
      fi
    else
      # Node is in the distribution complete stage execute during the upgrade process
      echo "Hotfix: $JBugID node is in distribution complete stage,Pending: $FileEx will execute during upgrade" | $IB_LOG
      ExecuteFile $FileEx $SubBugID $HardwareType $ALT_EXECUTE_PENDING_DIR 1
      ReturnCode=$?
      # Need this below flag to maintain a sequence in execution(execonce)
      if [ $ReturnCode == 3 ]; then
        CP_EXEC_HF_PENDING=1
      fi
    fi

    if [ $ReturnCode == 1 ]; then
      # LogMessage on failure
      echo "Hotfix: $JBugID failed in executing $FileEx." | $IB_LOG
      LogMessages_RevertBack_All
      exit 1
    else
      GenerateCSVfile $FileEx $RestartWeight "$Action" $CsvFile $ReturnCode $FileOp_Execute $FileType
    fi
  done 
}

function ExecuteFile {
  # Make sure we're passed 5 arguments
  if [[ $# != 5 ]]; then
    echo "ExecuteFile was not passed 5 arguments:" | $IB_LOG
    echo "  Args Passed: $*" | $IB_LOG
    return 1
  fi

  # Assign the arguments to variables
  Execute_file=$(echo $1)
  SBugID=$(echo $2)
  Hw_type=$(echo $3)
  ExecTargetDir=$(echo $4)
  Do_pending=$(echo $5)

  # First make sure the execute file exists
  if [[ ! -f ./$Execute_file ]]; then
    echo "Hotfix: $JBugID File ./$Execute_file does not exist" | $IB_LOG
    return 1
  fi
  
  # Make sure hardware checks if needed
  if [[ $HardwareType != "ALL" ]]; then
    CheckHardware $HardwareType $Execute_file
    if [ $? != 0 ]; then
      return 2
    fi
  fi

  # Make sure not to run already executed in the previous hotfix
  # Only validate during CHF versions
  result=`./$MANIFEST_FILE_UTILITY --validate file_exe --hf_version $HfTag --bugid $JBugID --nios_version $Version --file "$Execute_file" --hf_operation apply`
  ParseRcResult "$result"

  if [[ $RC == 14 ]]; then
    echo "Hotfix: $JBugID $Execute_file already executed in previous hotfix ignoring execution." | $IB_LOG
    return 2
  fi
  
  if [[ $RC != 0 ]]; then
    echo "Hotfix: $JBugID $Execute_file failed in validation ignoring execution." | $IB_LOG
    return 1
  fi

  # Create the executable directory
  if [[ ! -d ${ExecTargetDir} ]]; then
    mkdir -p -m 775 $ExecTargetDir
  else
    chmod 755 $ExecTargetDir
  fi

  #Copy the executables to pending directory
  if [[ $RC == 0 ]]; then
    if ! cp -f ./$Execute_file "${ExecTargetDir}/" 2>&1; then
      echo "Hotfix: $JBugID failed cp ./$Execute_file to ${ExecTargetDir}" | $IB_LOG
      return 1
    else
      echo "Hotfix: $JBugID copied ./$Execute_file to ${ExecTargetDir}." | $IB_LOG
      # Make sure the permissions are set correctly on the file
      if ! chmod $Perms_EX "${ExecTargetDir}/$Execute_file" 2>&1; then
        echo "Hotfix: $JBugID chmod $Perms_EX $Execute_file failed" | $IB_LOG
      fi
      # Don't execute now, execute during restart or after upgrade
      if [[ $Do_pending == 1 ]]; then
        return 3
      fi
    fi
  fi

  # Files to execute directly on the node. 
  if [ -x "${ExecTargetDir}/$Execute_file" ]; then
    echo "Hotfix: $JBugID Trying to execute $Execute_file" | $IB_LOG
    # Move to target directory and execute
    cd "$ExecTargetDir"
    ./"$Execute_file" || echo "Hotfix: $JBugID Error running $Execute_file" 2>&1 > /dev/null | $IB_LOG
    echo "Hotfix: $JBugID Removing $Execute_file" | $IB_LOG
    rm -f "$Execute_file"
    cd -
    return 0
  elif [ -f "${ExecTargetDir}/$Execute_file" ]; then
    echo "Hotfix: $JBugID Not a executable ignoring executing $Execute_file" | $IB_LOG
    return 2
  fi

  echo "Hotfix: $JBugID failed ignoring executing $Execute_file" | $IB_LOG
  return 1
}

# execonce should execute only on active partition
function ExeconceFiles {
  # Modify
  ExeconceFilesModify

  # Add
  ExeconceFilesAdd

  # Delete
  ExeconceFilesDelete

  # DEBIANs
  ExeconceDEBIANS
}

function ExeconceFilesModify {
  NeedExeconce=0
  # Update the files in runonce csv after validations
  for i in ${!OnRestartModifyFiles[@]}; do
    EachFile=${OnRestartModifyFiles[i]}
    FileEx=$(echo $EachFile | cut -d ',' -f1)
    DirPath=$(echo $EachFile | cut -d ',' -f2)
    Perm=$(echo $EachFile | cut -d ',' -f3)
    MD5SUM_REF=$(echo $EachFile | cut -d ',' -f4)
    SubBugID=$(echo $EachFile | cut -d ',' -f5)
    HardwareType=$(echo $EachFile | cut -d ',' -f6)

    # If Dir is not ending with '/', then add it
    if [[ ${DirPath: -1} != "/" ]]; then
      DirPath=$DirPath/
    fi

    # Validate files
    if [[ $IsActive == 1 ]]; then
      CopyFile $BackupTag $DirPath $FileEx $Perm $HardwareType 1
    else
      CopyFile $BackupTag $DirPath $FileEx $Perm $HardwareType 0
    fi
    ReturnCode=$?
    if [[ $ReturnCode == 0 ]]; then
      # Alternate partition copy success
      # Update CSV file with the modified status
      GenerateCSVfile $DirPath$FileEx $RestartWeight "$ActionReboot" $CsvFile $ReturnCode $FileOp_Mod $FileType
    elif [[ $ReturnCode == 1 ]]; then
      # Execute LogMessages_RevertBack
      echo "Hotfix: $JBugID failed in applying $FileEx file revert back applied changes." | $IB_LOG
      $SYSLOG "Hotfix: $JBugID failed in applying $FileEx file revert back applied changes."
      LogMessages_RevertBack_All
    elif [[ $ReturnCode == 2 ]]; then
      # Update CSV file with skipped status
      GenerateCSVfile $DirPath$FileEx $RestartWeight "$ActionRestart" $CsvFile $ReturnCode $FileOp_Mod $FileType
    elif [[ $ReturnCode == 3 ]]; then
      # Update CSV file with a pending action
      # Note If FIPS is enabled copy the files to the reboot dir, FIPS integrity tests fails if changes
      # apply during restart
      GetFIPSVal
      GenerateCSVfile $DirPath$FileEx $TMPWEIGHT "$TMPACTION" $CsvFile $ReturnCode $FileOp_Mod $FileType
      CopyFilesRRTmpDir $FileEx $TMPDIR "$TMPOP"
      if [[ $SWITCHRUNONCE == 1 ]]; then
        NeedRunonce=$NeedRunonce
      else
        NeedExeconce=$NeedExeconce
      fi
    else
      echo "Hotfix: $JBugID failed unexpected return code:$ReturnCode. Revert back applied changes" | $IB_LOG
      LogMessages_RevertBack_All
    fi
  done  
}

function ExeconceFilesAdd {
  # Add the files in runonce csv after validations
  for i in ${!OnRestartAddFiles[@]}; do
    RevertFileIndex=i
    EachFile=${OnRestartAddFiles[i]}
    Filenew=$(echo $EachFile | cut -d ',' -f1)
    DirPath=$(echo $EachFile | cut -d ',' -f2)
    Perm=$(echo $EachFile | cut -d ',' -f3)
    MD5SUM_REF=$(echo $EachFile | cut -d ',' -f4)
    SubBugID=$(echo $EachFile | cut -d ',' -f5)
    HardwareType=$(echo $EachFile | cut -d ',' -f6)

    # If Dir is not ending with '/', then add it
    if [[ ${DirPath: -1} != "/" ]]; then
      DirPath=$DirPath/
    fi

    # Validate files
    if [[ $IsActive == 1 ]]; then
      AddFile $BackupTag $DirPath $Filenew $Perm $HardwareType 1
    else
      AddFile $BackupTag $DirPath $Filenew $Perm $HardwareType 0
    fi
    ReturnCode=$?
    if [[ $ReturnCode == 0 ]]; then
      # Alternate parition add success
      GenerateCSVfile $DirPath$Filenew $RestartWeight "$ActionReboot" $CsvFile $ReturnCode $FileOp_Add $FileType
    elif [[ $ReturnCode == 1 ]]; then
      # Execute LogMessages_RevertBack
      echo "Hotfix: $JBugID failed in applying $Filenew file revert back applied changes." | $IB_LOG
      $SYSLOG "Hotfix: $JBugID failed in applying $FilenewFilenew file revert back applied changes."
      LogMessages_RevertBack_All
    elif [[ $ReturnCode == 2 ]]; then
      # Update CSV file with skipped status
      GenerateCSVfile $DirPath$Filenew $RestartWeight "$ActionRestart" $CsvFile $ReturnCode $FileOp_Add $FileType
    elif [[ $ReturnCode == 3 ]]; then
      # Note If FIPS is enabled copy the files to the reboot dir, FIPS integrity tests fails if changes
      # apply during restart
      # Update CSV file with a pending action
      # Default consider reboot needed
      GetFIPSVal
      GenerateCSVfile $DirPath$Filenew $TMPWEIGHT "$TMPACTION" $CsvFile $ReturnCode $FileOp_Add $FileType
      CopyFilesRRTmpDir $Filenew $TMPDIR "$TMPOP"
      if [[ $SWITCHRUNONCE == 1 ]]; then
        NeedRunonce=$NeedRunonce
      else
        NeedExeconce=$NeedExeconce
      fi
    else
      echo "Hotfix: $JBugID failed unexpected return code:$ReturnCode. Revert back applied changes" | $IB_LOG
      LogMessages_RevertBack_All
    fi
  done
}

function ExeconceFilesDelete {
  # Delete the files in execonce csv after validations
  for i in ${!OnRestartDeleteFiles[@]}; do
    RevertFileIndex=i
    EachFile=${OnRestartDeleteFiles[i]}
    FileDl=$(echo $EachFile | cut -d ',' -f1)
    DirPath=$(echo $EachFile | cut -d ',' -f2)
    SubBugID=$(echo $EachFile | cut -d ',' -f3)
    HardwareType=$(echo $EachFile | cut -d ',' -f4)

    # If Dir is not ending with '/', then add it
    if [[ ${DirPath: -1} != "/" ]]; then
      DirPath=$DirPath/
    fi

    # Validate files before delete
    if [[ $IsActive == 1 ]]; then
      DeleteFile $DirPath $FileDl $HardwareType 1
    else
      DeleteFile $DirPath $FileDl $HardwareType 0
    fi
    ReturnCode=$?
    if [[ $ReturnCode == 0 ]]; then
      # Alternate delete success
      GenerateCSVfile $DirPath$FileDl $RestartWeight "$ActionReboot" $CsvFile $ReturnCode $FileOp_Del $FileType
    elif [[ $ReturnCode == 1 ]]; then
      # Execute LogMessages_RevertBack
      echo "Hotfix: $JBugID failed in applying $FileDl file revert back applied changes." | $IB_LOG
      $SYSLOG "Hotfix: $JBugID failed in applying $FileDl file revert back applied changes."
      LogMessages_RevertBack_All
    elif [[ $ReturnCode == 2 ]]; then
      # Update CSV file with skipped status
      GenerateCSVfile $DirPath$FileDl $RestartWeight "$ActionRestart" $CsvFile $ReturnCode $FileOp_Del $FileType
    elif [[ $ReturnCode == 3 ]]; then
      # Note If FIPS is enabled copy the files to the reboot dir, FIPS integrity tests fails if changes
      # apply during restart
      # Update CSV file with a pending action
      # Default consider reboot needed
      GetFIPSVal
      GenerateCSVfile $DirPath$FileDl $TMPWEIGHT "$TMPACTION" $CsvFile $ReturnCode $FileOp_Del $FileType
      if [[ $SWITCHRUNONCE == 1 ]]; then
        NeedRunonce=1
      else
        NeedExeconce=1
      fi
    else
      echo "Hotfix: $JBugID failed unexpected return code:$ReturnCode. Revert back applied changes" | $IB_LOG
      LogMessages_RevertBack_All
    fi
  done
}

function ExeconceDEBIANS {
  # Make sure not to install already installed DEBIANs
  
  for i in ${!OnRestartDEBIANInstall[@]}; do
    RevertFileIndex=i
    EachFile=${OnRestartDEBIANInstall[i]}
    DEBIANName=$(echo $EachFile | cut -d ',' -f1)
    CName=$(echo $EachFile | cut -d ',' -f2)
    CVersion=$(echo $EachFile | cut -d ',' -f3)
    SBugID=$(echo $EachFile | cut -d ',' -f4)
    HardwareType=$(echo $EachFile | cut -d ',' -f5)
	
    #Validate DEBIAN needs to be installed
    CheckDEBIANInstall $CName $CVersion $HardwareType
    ReturnCodeDEBIAN=$?
    if [[ $ReturnCodeDEBIAN == 0 || $ReturnCodeDEBIAN == 2 || $ReturnCodeDEBIAN == 8 ]]; then
      # Note If FIPS is enabled copy the files to the reboot dir, FIPS integrity tests fails if changes
      # apply during restart
      CDEBIANName="${CName}:${CVersion}:${DEBIANName}"
      GetFIPSVal
      CopyDEBIANTmpDIR $DEBIANName $ReturnCodeDEBIAN "${CDEBIANName}" $TMPDIR $TMPWEIGHT "${TMPACTION}"
      if [[ $SWITCHRUNONCE == 1 ]]; then
        NeedRunonce=$NeedRunonce
      else
        NeedExeconce=$NeedExeconce
      fi
    else
      echo "Hotfix: $JBugID failed fetching DEBIAN validation: $ReturnCodeDEBIAN" | $IB_LOG
      LogMessages_RevertBack_All
    fi
  done
}

function RestoreModifyFile {
  # Make sure we're passed 3 arguments
  if [[ $# != 3 ]]; then
    echo "RestoreFile was not passed 3 arguments:" | $IB_LOG
    echo "  Args Passed: $*" | $IB_LOG
    return 1
  fi

  # Assign the arguments to variables
  # stripping white space in the process
  Bug=$(echo $1)
  File=$(echo $2)
  TargetDir=$(echo $3)

  # Make sure none of the variables are empty strings
  if [[ -z $Bug || -z $File || -z $TargetDir ]]; then
    echo "RestoreModifyFile: One or more of the arguments passed was empty" | $IB_LOG
    echo "  Bug: $Bug" | $IB_LOG
    echo "  File: $File" | $IB_LOG
    echo "  TargetDir: $TargetDir" | $IB_LOG
    return 1
  fi

  # Validate the alternate path and set it accordingly
  if [[ $IsAlternate == 1 ]]; then
    if [[ $TargetDir == '?/$TargetDir/?(*)' ]]; then
      TargetDir=$alt_storage$TargetDir
    else
      TargetDir=$alt_path$TargetDir
    fi
  fi

  ModBackupDir=$TargetDir

  # Generate fully qualified backup and target file names
  Backup="${ModBackupDir}/${File}.$Bug"
  Target="${TargetDir}/$File"

  # Make sure the backup file exists
  if [[ ! -f $Backup ]]; then
    echo "Hotfix: $JBugID Backup file $Backup does not exist" | $IB_LOG
    return 1
  fi

  # Make sure the target file exists
  if [[ ! -f $Target ]]; then
    echo "Hotfix: $JBugID Target file $Target does not exist" | $IB_LOG
    return 1
  fi

  # Replace the new file with the backed up copy
  if ! mv -f $Backup $Target 2>&1; then
    echo "mv $Backup $Target failed" | $IB_LOG
    return 1
  fi

  echo "Hotfix: $JBugID Reverted $Target file" | $IB_LOG

  return 0
  }

function RestoreAddFile {
  # Make sure we're passed 3 arguments
  if [[ $# != 3 ]]; then
    echo "RestoreAddFile was not passed 3 arguments:" | $IB_LOG
    echo "  Args Passed: $*" | $IB_LOG
    return 1
  fi

  # Assign the arguments to variables
  # stripping white space in the process
  Bug=$(echo $1)
  File=$(echo $2)
  TargetDir=$(echo $3)
  BackupDir=$HfBackupDir

  # Make sure none of the variables are empty strings
  if [[ -z $Bug || -z $File || -z $BackupDir || -z $TargetDir ]]; then
    echo "RestoreAddFile: One or more of the arguments passed was empty" | $IB_LOG
    echo "  Bug: $Bug" | $IB_LOG
    echo "  File: $File" | $IB_LOG
    echo "  BackupDir: $BackupDir" | $IB_LOG
    echo "  TargetDir: $TargetDir" | $IB_LOG
    return 1
  fi

  # Validate the alternate path and set it accordingly
  if [[ $IsAlternate == 1 ]]; then
    if [[ $TargetDir == '?/$TargetDir/?(*)' ]]; then
      TargetDir=$alt_storage$TargetDir
    else
      TargetDir=$alt_path$TargetDir
    fi
  fi

  # Generate fully qualified backup and target file names
  Backup="${BackupDir}/${File}"
  Target="${TargetDir}/$File"

  # Make sure the backup file exists
  if [[ ! -f $Backup ]]; then
    echo "Restore $File not modified in $JBugID" | $IB_LOG
    return 1
  fi

  # Make sure the target file exists
  if [[ ! -f $Target ]]; then
    echo "Target file $Target does not exist" | $IB_LOG
    return 1
  fi

  # remove the added file
  if ! rm -f $Target 2>&1; then
    echo "rm $Target failed" | $IB_LOG
    return 1
  fi

  echo "Hotfix: $JBugID Reverted $Target file success." | $IB_LOG

  return 0
  }


function RestoreDeleteFile {
  # Make sure we're passed 3 arguments
  if [[ $# != 3 ]]; then
    echo "RestoreFile was not passed 3 arguments:" | $IB_LOG
    echo "  Args Passed: $*" | $IB_LOG
    return 1
  fi

  # Assign the arguments to variables
  # stripping white space in the process
  Bug=$(echo $1)
  File=$(echo $2)
  TargetDir=$(echo $3)
  BackupDir=$BackupDir

  # Make sure none of the variables are empty strings
  if [[ -z $Bug || -z $File || -z $BackupDir || -z $TargetDir ]]; then
    echo "RestoreDeleteFile: One or more of the arguments passed was empty" | $IB_LOG
    echo "  Bug: $Bug" | $IB_LOG
    echo "  File: $File" | $IB_LOG
    echo "  BackupDir: $BackupDir" | $IB_LOG
    echo "  TargetDir: $TargetDir" | $IB_LOG
    return 1
  fi

  # Validate the alternate path and set it accordingly
  if [[ $IsAlternate == 1 ]]; then
    if [[ $TargetDir == '?/$TargetDir/?(*)' ]]; then
      TargetDir=$alt_storage$TargetDir
    else
      TargetDir=$alt_path$TargetDir
    fi
  fi

  # Generate fully qualified backup and target file names
  Backup="${BackupDir}/${File}"
  Target="${TargetDir}/$File"

  # Make sure the backup file exists
  if [[ ! -f $Backup ]]; then
    echo "Hotfix: $JBugID Backup file $Backup does not exist" | $IB_LOG
    return 1
  fi

  # Replace the new file with the backed up copy
  if ! mv -f $Backup $Target 2>&1; then
    echo "mv $Backup $Target failed" | $IB_LOG
    return 1
  fi

  echo "Hotfix: $JBugID Reverted $Target file success." | $IB_LOG

  return 0
  }


function LogMessages_RevertBack_All {
  # Make sure we revert all applied changes from a backup copy
  LogMessages_RevertBack_Modify
  LogMessages_RevertBack_Add
  LogMessages_RevertBack_Delete
  DeleteTmpDir 1
  DeleteRunonceExeconce
  umount -l $ROOTFS
  rmdir $ROOTFS
  echo "Hotfix: $JBugID reverted all" | $IB_LOG
  exit 1
}


function LogMessages_RevertBack_Modify {
  # Revert back all the modified file for this version
  for i in ${!ModifyFiles[@]}; do
    RevertFileIndex=i
    EachFile=${ModifyFiles[i]}
    File=$(echo $EachFile | cut -d ',' -f1)
    TargetDir=$(echo $EachFile | cut -d ',' -f2)
    RestoreModifyFile $BackupTag $File $TargetDir
  done

  # Revert back runonce & execonce modify files in alternate
  if [[ "$IsActive" != 1 ]]; then
    for i in ${!OnRebootModifyFiles[@]}; do
      RevertFileIndex=i
      EachFile=${OnRebootModifyFiles[i]}
      File=$(echo $EachFile | cut -d ',' -f1)
      TargetDir=$(echo $EachFile | cut -d ',' -f2)
      RestoreModifyFile $BackupTag $File $TargetDir
    done

    for i in ${!OnRestartModifyFiles[@]}; do
      RevertFileIndex=i
      EachFile=${OnRestartModifyFiles[i]}
      File=$(echo $EachFile | cut -d ',' -f1)
      TargetDir=$(echo $EachFile | cut -d ',' -f2)
      RestoreModifyFile $BackupTag $File $TargetDir
    done
  fi

}

function LogMessages_RevertBack_Add {
  # Delete all the added file for this version
  for i in ${!AddedFiles[@]}; do
    RevertFileIndex=i
    EachFile=${AddedFiles[i]}
    File=$(echo $EachFile | cut -d ',' -f1)
    TargetDir=$(echo $EachFile | cut -d ',' -f2)
    RestoreAddFile $BackupTag $File $TargetDir
  done

  # revert back added files in the alternate partition
  if [[ "$IsActive" != 1 ]]; then
    for i in ${!OnRebootAddFiles[@]}; do
      RevertFileIndex=i
      EachFile=${OnRebootAddFiles[i]}
      File=$(echo $EachFile | cut -d ',' -f1)
      TargetDir=$(echo $EachFile | cut -d ',' -f2)
      RestoreAddFile $BackupTag $File $TargetDir
    done

    for i in ${!OnRestartAddFiles[@]}; do
      RevertFileIndex=i
      EachFile=${OnRestartAddFiles[i]}
      File=$(echo $EachFile | cut -d ',' -f1)
      TargetDir=$(echo $EachFile | cut -d ',' -f2)
      RestoreAddFile $BackupTag $File $TargetDir
    done
  fi
}

function LogMessages_RevertBack_Delete {
  # Add back all the deleted file for this version
  for i in ${!DeletedFiles[@]}; do
    RevertFileIndex=i
    EachFile=${DeletedFiles[i]}
    File=$(echo $EachFile | cut -d ',' -f1)
    TargetDir=$(echo $EachFile | cut -d ',' -f2)
    RestoreDeleteFile $BackupTag $File $TargetDir
  done

  # revert back deleted files during runonce in alternate partition
  if [[ "$IsActive" != 1 ]]; then
    for i in ${!OnRebootDeleteFiles[@]}; do
      RevertFileIndex=i
      EachFile=${OnRebootDeleteFiles[i]}
      File=$(echo $EachFile | cut -d ',' -f1)
      TargetDir=$(echo $EachFile | cut -d ',' -f2)
      RestoreDeleteFile $BackupTag $File $TargetDir
    done

    for i in ${!OnRestartDeleteFiles[@]}; do
      RevertFileIndex=i
      EachFile=${OnRestartDeleteFiles[i]}
      File=$(echo $EachFile | cut -d ',' -f1)
      TargetDir=$(echo $EachFile | cut -d ',' -f2)
      RestoreDeleteFile $BackupTag $File $TargetDir
    done
  fi
}

# echo "True" if we're running on a GM or GMC, "False" otherwise
is_gmc () {
    python <<EOF
from infoblox.one import onedb,util
db = onedb.Db()
with db.begin(onedb.RO):
  print str(util.get_my_vnode(db)['is_potential_master'])
EOF
}

function GenerateHfFolders {
  # Generate mandatory folders, doesn't care on autorevert
  # Create GM manifest file dir only on GM
  # GMC (potential master)
  IS_GMC=$(is_gmc)
  if [ -f $CLUSTER_STATUS_FILE ] && [ ! -d $GM_MF_CHFDIR ]; then
    if ( grep -Fxq "ID Grid Master" $CLUSTER_STATUS_FILE ) || [ "${IS_GMC}" == "True" ]; then
      if ! mkdir -p "$GM_MF_CHFDIR"; then
        echo "Hotfix: $JBugID failed in creating $GM_MF_CHFDIR" | $IB_LOG
      fi
    fi
  fi
  # Create member manifest file dir
  if [ ! -d "$MEM_MF_CHFDIR" ]; then
    if ! mkdir -p "$MEM_MF_CHFDIR"; then
      echo "Hotfix: $JBugID failed in creating $MEM_MF_CHFDIR" | $IB_LOG
    fi
  fi
}

function DeleteTmpDir {
  tmpdir=$(echo $1)
  # Delete all directories created.
  if ! rm -rf "$HfBackupDir" 2>&1; then
    echo "rm $BackupDir failed" | $IB_LOG
  fi
  if [[ "$tmpdir" == 1 ]]; then
    if [ -d $TMP_REBOOT_DIR ]; then
      if ! rm -rf $TMP_REBOOT_DIR 2>&1; then
        echo "rm -rf $TMP_REBOOT_DIR failed" | $IB_LOG
      fi
    fi
    if [ -d $TMP_RESTART_DIR ]; then
      if ! rm -rf $TMP_RESTART_DIR 2>&1; then
        echo "rm -rf $TMP_RESTART_DIR failed" | $IB_LOG
      fi
    fi
    if [ -d $ALT_EXECUTE_PENDING_DIR ]; then
      if ! rm -rf $ALT_EXECUTE_PENDING_DIR 2>&1; then
        echo "rm -rf $ALT_EXECUTE_PENDING_DIR failed" | $IB_LOG
      fi
    fi
  fi
}

function DeleteRunonceExeconce {
  # Delete runonce and execonce on cleanup
  if [ -f $EXEC_ONCE_ON_RESTART_FQFILE ]; then
    if ! rm -f $EXEC_ONCE_ON_RESTART_FQFILE 2>&1; then
      echo "rm $EXEC_ONCE_ON_RESTART_FQFILE failed" | $IB_LOG
    fi
  fi
  if [ -f "$ROOTFS"/$RUN_ONCE_ON_REBOOT_FQFILE ]; then
    if ! rm -f "$ROOTFS"/$RUN_ONCE_ON_REBOOT_FQFILE 2>&1; then
      echo "rm "$ROOTFS"/$RUN_ONCE_ON_REBOOT_FQFILE failed" | $IB_LOG
    fi
  fi
}

function ValidateAlternate {
  # Check if the upgrade is in progress
  IsAlternate=0
  if [ -d /infoblox/var/upgrade/ ];then
    #get the current upgrade state
    UPGRADE_STATE=`cat /infoblox/var/upgrade/UPGRADE_STATE`

    #If the upgrade state is distribution_complete then proceed for applying hotfix on the alternate partition
    if [ "$UPGRADE_STATE" == "distribution_complete" ]; then
      # mount the alternate partitions
      mount_alternate_partitions

      # Get the version for alternate partition release
      alt_Version=$(/bin/grep 'CLIENT_VERSION' /storage/alternate_config | /bin/sed -e 's/CLIENT_VERSION=//')

      # If the version is 8.6.1-421683 then apply the  hotfix
      if [ $alt_Version  == $Version ] ; then
        alt_path='/mnt/nios/rootfs'
        alt_storage='/mnt_storage'
        part='alternate'
        IsAlternate=1
        return 0
      else
	umount /mnt > /dev/null 2>&1 || true
	umount /mnt_storage > /dev/null 2>&1 || true
        return 1
      fi
    fi
  else
    echo "Hotfix: $JBugID failed NIOS version not matching." | $IB_LOG
    return 1
  fi
}

function Unmount {
  if [[ $IsAlternate == 1 ]]; then
    # make sure /mnt is not mounted
    umount /mnt > /dev/null 2>&1 || true
    umount /mnt_storage > /dev/null 2>&1 || true
  fi
  if [[ -d $ROOTFS ]]; then
    rmdir $ROOTFS
  fi
}


function GenerateCSVfile  {
  # Make sure we're passed 7 arguments
  if [[ $# != 7 ]]; then
    $SYSLOG "CHF: failed in Log_Actions was not passed 7 arguments, Args Passed: $*"
    echo "CHF: failed in Log_Actions was not passed 5 arguments" | $IB_LOG
    echo "Args Passed: $*" | $IB_LOG
    exit 1
  fi

  File=$1
  Weight=$2
  Action_gen=$3
  Path=$4
  RC=$5
  FileOp=$6
  GenFileType=$7  

  if [[ ! -f $Path ]]; then
    CsvDir=`dirname $CsvFile`
    mkdir -p $CsvDir
    echo "type,binary,weight,action,file_operation" >> $Path
  fi

  if [[ $RC == 0 || $RC == 3 ]]; then
    echo "$GenFileType,$File,$Weight,"$Action_gen",$FileOp" >> $Path
  elif [[ $RC == 2 ]]; then
    echo "$GenFileType,$File,$Weight,"$Action_gen",$FileOp_Skip" >> $Path
  else
    echo "Hotfix: $JBugID GenerateCSVfile: Failed unexpected $RC" | $IB_LOG
  fi
}

function CheckHardware {
  # Make sure we're passed 2 arguments
  if [[ $# != 2 ]]; then
    echo "CheckHardware was not passed 2 arguments:" | $IB_LOG
    echo "Args Passed: $*" | $IB_LOG
    return 1
  fi

  # Assign the arguments to variables
  # stripping white space in the process
  input_hw_type=$(echo $1)
  File=$(echo $2)
  hw_type=`cat /infoblox/var/hwtype.txt`
  if [[ $input_hw_type == $hw_type ]]; then
    # Hardware matched
    return 0
  else
    echo "Hotfix: $JBugID $File Skipping, Hardware miss match with $input_hw_type having $hw_type." | $IB_LOG
    return 1
  fi
}

function ValidateRunexeconce {
  # Terminate if runonce or execonce was present from the previous hotfix
  mkdir -p $ROOTFS
  mount --bind / $ROOTFS
  # Fail if rc.runonce existing
  if [ -x "$ROOTFS"/$RUN_ONCE_ON_REBOOT_FQFILE ]; then
    echo "Hotfix: $JBugID rc.runonce exist!  Please reboot first and then apply the hotfix again" | $IB_LOG
    umount -l $ROOTFS
    rmdir $ROOTFS
    exit 1
  fi

  umount -l $ROOTFS

  # Fail if exec_once_on_restart existing
  if [ -x $EXEC_ONCE_ON_RESTART_FQFILE ]; then
    echo "Hotfix: $JBugID exec_once_on_restart exist!  Please restart first and then apply the hotfix again" | $IB_LOG
    exit 1
  fi
}

function ValidateActiveVersion {
  # Get the currently running version
  CUR_VER=$(/bin/grep 'CLIENT_VERSION' /infoblox/config | /bin/sed -e 's/CLIENT_VERSION=//')
  IsActive=0
  # If running version is matched with the hotfix nios version, then proceed to apply the hotfix
  if [ $CUR_VER == $Version ]; then
    IsActive=1
    part='active'
    return 0
  else
    echo "Hotfix: $JBugID Active partition NIOS version not matching with $Version" | $IB_LOG
    return 1
  fi
}

function ValidateVersion {
  # Validate if the NIOS Version that can be installed on Active or Alternate partition
  CanApply=0
  ValidateActiveVersion
  ReturnCodeActive=$?
  if [ $ReturnCodeActive == 0 ] ; then
    CanApply=1
    return 1
  elif [[ $CanApply == 0 ]] ; then
    ValidateAlternate
    ReturnCodeAlt=$?
    if [[ $ReturnCodeAlt == 0 && $CanApply == 0 ]]; then
      return 2
    else
      echo "Hotfix: $JBugID Invalid Hotfix version, exiting." | $IB_LOG
      exit 1
    fi
  else
    echo "Hotfix: $JBugID Invalid Hotfix version trying to apply" | $IB_LOG
    exit 1
  fi	  
}

function ValidateHotfix {
  # Check if any runonce or execonce present and fail
  ValidateRunexeconce

  # Validate if the Hotfix can be applied  
  # validate version
  ValidateVersion
  # Validate the basic Hotfix validations
  # 1: Validate the same hotfix
  # 2: Validate out-of order apply
  # 3: Validate invalid hotfix

  # Check for the manifest file and set the permissions
  if [[ -f "./$MANIFEST_FILE_UTILITY" ]]; then
    if ! chmod $Perms_EX "${MANIFEST_FILE_UTILITY}" 2>&1; then
      echo "chmod $Perms_EX $MANIFEST_FILE_UTILITY failed" | $IB_LOG
    fi
  else
    echo "Hotfix: $JBugID failed missing manifest file." | $IB_LOG
    exit 1
  fi
  result=`./$MANIFEST_FILE_UTILITY --validate install --hf_version $HfTag --nios_version $Version --bugid $JBugID --part $part`
  ParseRcResult "${result}"
  ReturnCode=$RC
  if [ $ReturnCode != 0 ]; then
    echo "Hotfix: $JBugID failed validation with: $result" | $IB_LOG
    exit 1
  fi

  # Create mandatory folders
  GenerateHfFolders
}

function ParseRcResult {
  # Make sure we're passed 1 argument
  if [[ $# != 1 ]]; then
    echo "ParseRcResult was not passed 1 argument:" | $IB_LOG
    echo "Args Passed: $*" | $IB_LOG
    return 1
  fi

  # Assign the arguments to variables
  # stripping white space in the process
  Result=$(echo $1)
  pattern='"([^"]*)".*"([^"]*)"'

  if [[ $Result =~ $pattern ]]; then
    echo "RC: ${BASH_REMATCH[1]}" | $IB_LOG
    echo "MSG: ${BASH_REMATCH[2]}" | $IB_LOG
    RC=${BASH_REMATCH[1]}
    MSG=${BASH_REMATCH[2]}
  else
    echo "Hotfix: $JBugID failed to parse:$Result" | $IB_LOG
    RC=1
  fi
}

function GetCSVFile {
  # Get the Input CSV file for manifest file generation
  epoch_time=$(date +"%s")
  result=`./$MANIFEST_FILE_UTILITY --hf_version $HfTag --get_cfn  --hf_operation apply --time_epoch $epoch_time --bugid $JBugID`
  ParseRcResult "$result"
  CsvFile="${MSG}"
}

#Start generating the Manifest file using CSV file
function GenerateManifestFile {
  # Make sure we're passed 1 argument
  if [[ $# != 1 ]]; then
    echo "GenerateManifestFile was not passed 1 argument:" | $IB_LOG
    echo "Args Passed: $*" | $IB_LOG
    return 1
  fi

  # Assign the arguments to variables
  # stripping white space in the process
  filepath=$(echo $1)
  result=`./$MANIFEST_FILE_UTILITY --hf_version $HfTag --gen_mf --csv_file $filepath --part $part --nios_version $Version --hf_operation apply --time_epoch $epoch_time --bugid $JBugID --ign_revert $Ignore_HF_Revert`
  ParseRcResult "$result"
  ReturnCode=$RC
  if [ $ReturnCode != 0 ]; then
    echo "Hotfix: $JBugID Generation of manifest file failed with code:$ReturnCode $MSG" | $IB_LOG
  else
    echo "Hotfix: $JBugID Generation of manifest file completed" | $IB_LOG
  fi
}

#Start applying Hotfix
function StartApply {
  # Make sure we're passed 1 argument
  if [[ $# != 1 ]]; then
    echo "StartApply was not passed 1 argument:" | $IB_LOG
    echo "Args Passed: $*" | $IB_LOG
    return 1
  fi

  # Assign the arguments to variables
  DoAction=$(echo $1) 
  
  if [[ $DoAction == "Modify" ]]; then
    # Modifying files
    ModifyFiles
  fi 

  if [[ $DoAction == "Add" ]]; then
    # Add files
    AddFiles
  fi

  if [[ $DoAction == "Delete" ]]; then
    # Delete files
    DeleteFiles
  fi

  # Apply during runonce (Reboot)
  if [[ $DoAction == "runonce" ]]; then
    # Files ops on reboot
    RunonceFiles
  fi

  # Apply during execonce (Restart)
  if [[ $DoAction == "execonce" ]]; then
    # Files ops on restart
    ExeconceFiles
  fi

  # Execute the scripts during hotfix apply
  if [[ $DoAction == "execute" ]]; then
    ExecuteFiles
  fi

  # Execute the scripts during restart or at post upgrade
  # during distribution complete stage(alternate).
  Executables=0
  if [[ $DoAction == "execute_pending" ]]; then
    # Execute files
    ExecuteFiles_Pending
  fi

  # Copy execonce into FQ execonce path
  if [[ $NeedExeconce == 1 || $Executables == 1 || $CP_EXEC_HF_PENDING == 1 ]]; then
    CopyExeconce $Executables
  elif [[ $NeedRunonce == 1 ]]; then
    CopyRunonce
  fi
}


function DeleteDir
{
  if [[ $IsActive == 1 ]]; then
    # As a part of NIOS-99081, delete the directory for GM, GMC and Members in Active Version
    if ! rm -rf "$WEBUI_CONF_DIR" 2>&1; then
      echo "rm $WEBUI_CONF_DIR failed" | $IB_LOG
    fi
    echo "Hotfix CLEANUP: $JBugID Deleted $WEBUI_CONF_DIR" | $IB_LOG
  fi
}

function CreateDirAndFile
{
   # Validate the alternate path and set it accordingly
   if [[ "$IsAlternate" == 1 ]]; then
     CONF_DIR=$alt_path$DFAULT_CONF_DIR
   fi

   # If default_configuration folder doesnt exist
   if [[ ! -d $CONF_DIR  ]]; then
     # Create DFAULT_CONF_DIR and touch the file
     mkdir -p $CONF_DIR
     chmod $Perms_EX $CONF_DIR
     echo "Hotfix WARNING: $JBugID Created $CONF_DIR, since it was missing" | $IB_LOG
   fi
   if [[ ! -f "${CONF_DIR}/defaults.properties" ]]; then
     if ! touch "${CONF_DIR}/defaults.properties" 2>&1; then
       echo "touch ${CONF_DIR}/defaults.properties failed. " | $IB_LOG
     fi
     echo "Hotfix WARNING: $JBugID Empty file 'defaults.properties' created in ${CONF_DIR}, since file was not present." | $IB_LOG
   fi
}


#Start applying Hotfix
function StartHotfix {
  echo "Hotfix: $JBugID Apply started." | $IB_LOG
  $SYSLOG "Hotfix: $JBugID Apply started."
  # Check if the NIOS version matching with Active partition
  # If not an active version check for an alternate version
  ValidateHotfix

  # Patch to fix the WebUI folder and files
  CreateDirAndFile
 
  # Get the Input CSV file details for manifest file generation
  GetCSVFile

  # Modify existing files
  StartApply "Modify"

  # Add new files
  StartApply "Add"

  # Delete files
  StartApply "Delete"

  # Runonce files
  StartApply "runonce"

  # Runonce files
  StartApply "execonce"

  # Execute the files
  StartApply "execute"

  # Execute the files
  StartApply "execute_pending"

  # Patch to fix the WebUI folder and files
  DeleteDir

  #umount
  Unmount

  # Delete Tmp directories, not reboot or restart or pending directories
  DeleteTmpDir 0

  # Generate Manifest file
  GenerateManifestFile $CsvFile

  echo "Hotfix: $JBugID Apply successfully ended." | $IB_LOG
  $SYSLOG "Hotfix: $JBugID Apply successfully ended."
}
