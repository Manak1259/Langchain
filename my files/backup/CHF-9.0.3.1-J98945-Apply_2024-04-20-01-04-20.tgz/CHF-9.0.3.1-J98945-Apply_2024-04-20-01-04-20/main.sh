#!/usr/bin/perl

$true = (0==0);
$false = (0==1);
$applied = $false;
$directory = "/storage/support_hotfix";
$output_file = $directory . "/hotfix.txt";
$exitVal = 0; # initialize main.sh script return value to defult zero.

# Change the lists below as needed.  Don't list something in both include and exclude.  Exclude always wins.

# This is the member or list of members that you want the hotfix to execute on.  Should be list of IPs or "all".
@include_members = ("all");
# This is the member or list of members that you do not want the hotfix to execute on.  Should be list of IPs or "".
@exclude_members = ("");

$grid_status = `cat /infoblox/var/cluster_status.txt`;
chomp $grid_status;

if( -e "/infoblox/var/ha_status.txt" )
   {
    $ha_status = `cat /infoblox/var/ha_status.txt`;
    chomp $ha_status;
   }
else
   {
    $ha_status = "Active";
   }

open_new_log_file();
if (IsMyIpAddrInIncludeMember(myipaddr()))
{
        if (true)
        {
            $exitVal = process_hotfix();
            $applied = $true;
        }
        else
        {
       	    if (running_version() ne ""){
                print("Skipping execution due to version mismatch.\n");
                $exitVal = 3;
            }

            
        }
}
else
{
    print("Member ".myipaddr()." mismatch for ".join(',', @include_members).".\n");
    $exitVal = 5;
}
close_file();

exit $exitVal;

# functions below

sub IsMyIpAddrInIncludeMember()
{
    ($myIpAddr) = @_;

    foreach $imember (@include_members)
    {
        if (($imember eq $myIpAddr) || ($imember eq "all"))
        {
            return $true;
        } 
    }
    return $false;
}

sub not_excluded
   {
    ($this_one) = @_;
    foreach $exclude_member (@exclude_members)
       {
        if ($this_one eq $exclude_member)
           {
            return $false;
           }
       }
    return $true;
   }

sub myipaddr
   {
    $temp = `/sbin/ifconfig eth1 | /bin/grep 'inet addr:' | /bin/sed -e 's/.*addr://' -e 's/ .*//'`;
    chomp($temp);
    return $temp;
   }

sub open_new_log_file
   {
    if (-d $directory)
       {
        unlink $output_file if (-e $output_file);
       }
    else
       {
        $rc = mkdir($directory);
        if ($rc eq 0)
           {
            print "Can't make directory $directory: $!\n";
            exit 1;
           }
       }
    $rc = open(STDOUT, ">$output_file");
    if ($rc ne 1)
       {
        print "Can't open file $output_file: $!\n";
        exit 2;
       }
    else
       {
        print "New hotfix log file created for " . myipaddr() . " on " .`date` . "\n";
       }
    return 0;
   }

sub open_append_log_file
   {
    if (-d $directory)
       {
       }
    else
       {
        $rc = mkdir($directory);
        if ($rc eq 0)
           {
            print "Can't make directory $directory: $!\n";
            exit 1;
           }
       }
    $rc = open(STDOUT, ">>$output_file");
    if ($rc ne 1)
       {
        print "Can't open file $output_file: $!\n";
        exit 2;
       }
    else
       {
        print "\nHotfix log file reopened " .`date` . "\n\n";
       }
    return 0;
   }

sub delete_log_file
   {
    if (-d $directory)
       {
        unlink $output_file if (-e $output_file);
       }
    return 0;
   }

sub close_file
   {
    close STDOUT;
    if ($applied)
       {
        chdir($directory);
        `tar -czf /infoblox/var/hotfix.out *`;
       }
    else
       {
        chdir($directory);
        `tar -czf /infoblox/var/hotfix.out *`;
       }
    return;
   }
sub running_version
   {
    $ver = `/bin/grep 'CLIENT_VERSION' /infoblox/config | /bin/sed -e 's/CLIENT_VERSION=//'`;
    chomp($ver);
    return $ver;
   }
sub process_hotfix
   {
    print "Starting hotfix process here...\n";
    print `chmod 755 hotfix_script.sh`;
    $ret = system('./hotfix_script.sh');
    # Generally the perl scripts stores the return code from a system wait call is multiplied by 256 unless return code is -1.
    # So, do shift right by 8 bits (divide by 256), to get the actual return code received.
    if ($ret == -1)
       {
        print "failed to execute hotfix_script.sh: $!\n";
       }
    else
       {
        $ret = $ret >> 8;
       }
    if ($ret != 0)
       { 
        print "ERROR $ret detected while installing hotfix\n"; 
       }
    print "Ending hotfix process here...\n"; 
    return $ret;
   }
